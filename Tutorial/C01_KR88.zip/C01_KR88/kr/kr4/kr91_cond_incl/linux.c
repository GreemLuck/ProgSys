#include <stdio.h>

void printsys(void){
	printf("linux system\n");
}
