#include <stdio.h>

void printsys(void){
	printf("osx system\n");
}
