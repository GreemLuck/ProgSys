/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: ULn_mut v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // malloc, realloc, free
#include <string.h>  // strcpy, strlen                                  //---YYY
#include "../MTE/type_m.h"                                              //---YYY
#include "../ADT/STACK_DT_Specif.h"
#include "../ADT/STACK_SR_Specif.h"


/*------------------
Private declarations
------------------*/

typedef struct p_node_t {  // node of a 'simple linked' predecessor list
  elt_t e;                 // element to be stored in a node
  struct p_node_t *pred;   // points to the predecessor node
} p_node_t;

typedef struct stack_descr_t {
  p_node_t *top;     // points to the top node, i.e. last in element
  long size;         // number of elements in the STACK
} stack_descr_t;

/*--- sketch of the data structure -------------------------------      //---YYY    
        ---------      ---------------------
        | * | \0|      | * | * | * | * | \0|
        ---------      ---------------------
          |              |
          |              |
/-----| * | |  <-----| * | |
                pred   |
                      top
------------------------------------------------------------------------------*/


/*----------
Constructors
----------*/


void stack_create(stackt *_s, long cap)
//------------------------------------- 'cap' is not used for UL implementation
{
  //--- possibly find a free place and update descriptor
  stack_descr_t *s = malloc(sizeof *s);   // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)

  s->top = NULL;
  s->size = 0;
  *_s = s;
}


void stack_destroy(stackt *_s)
//----------------------------
{
  stack_descr_t *s = *_s;
  p_node_t *tmp = s->top;
  
  while (tmp != NULL)                                     // free STACK instance
  {
    s->top = tmp->pred;
    free(tmp->e.data);                                                  //---YYY
    free(tmp);
    tmp = s->top;
  }

  free(s);                                              // free STACK descriptor
  *_s = NULL;                                          // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- possibly find a new place
  p_node_t *tmp = malloc(sizeof *tmp);           // memory allocation: next node
                               // (is deallocated by stack_destroy or stack_get)

  tmp->e.data = malloc(strlen(e->data) + 1); // memory allocation: data //---YYY
                      // (is deallocated by stack_destroy or stack_get) //---YYY

  //--- copy *e and update descriptor
  tmp->e.key = e->key;                                                  //---YYY
  strcpy(tmp->e.data, e->data);                                         //---YYY
  tmp->pred = s->top;
  
  s->top = tmp;
  ++s->size; 
}


void stack_get(stackt _s,  elt_t *e)
//----------------------------------
{
  stack_descr_t *s = _s;
  p_node_t *tmp = s->top;

  //--- verify precondition
  if (tmp == NULL) exit(EXIT_FAILURE); // stack is empty
  
  //--- update *e and descriptor
  e->key = s->top->e.key;                                               //---YYY
  strcpy(e->data, s->top->e.data);                                      //---YYY

  s->top = tmp->pred;
  --s->size;

  //--- free space
  free(tmp->e.data);                                                    //---YYY
  free(tmp);                                            // free the old top node
}


/*--------------
Access functions
--------------*/


void stack_consult(stackt _s,  elt_t *e)
//--------------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty
  
  //--- update *e
  e->key = s->top->e.key;                                               //---YYY
  strcpy(e->data, s->top->e.data);                                      //---YYY
}


boolean_t stack_is_empty(stackt _s)
//---------------------------------
{
  stack_descr_t *s = _s;
  return s->top == NULL;
}


boolean_t stack_is_full(stackt _s)
//--------------------------------
{
  return FALSE;
}


boolean_t stack_is_mem_av(stackt _s)
//----------------------------------
{
  return TRUE;
}


/*---------------
Traverse function
---------------*/


void stack_traverse(stackt _s, void fct(buf_t *), buf_t *buf)
//-----------------------------------------------------------
{
  stack_descr_t *s = _s;
  p_node_t *tmp = s->top;
  
  while (tmp != NULL) {
    buf->elt1 = &tmp->e;
    fct(buf);
    tmp = tmp->pred;
  }
}
