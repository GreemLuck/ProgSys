/*--------------------------------------------------------------------------------
Title: Bounded input buffer
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 06, Dec. 11

DESCRIPTION
For obvious reasons, all input buffers have a maximal size, typically in the range 
from 8 (for older systems) to 1024 characters (for current systems). Normally, the
overflow is explicitly handled by an appropriate mechanism (e.g. ignore the new 
characters, empty the buffer when it is full, empty the buffer on some event, ...).

This is also the case for the 'printf' call, where the buffer is emptied with
every end of line character '\n' or when it is full (typically 1024 characters
under OSX 10.4, at least when the default output is the display).

This program illustrate this behavior in combination with the fork call!

USAGE
program_name [-e] (the 'e' option is for emptying the input buffer before overflow)

REMARK
Beware, a complete comprehension of the behavior of this program is really hard 
and requires a deep knowledge of: (1) printf's input buffering mechanism, and 
(2) the precise inheritance mechanism of the child process. 

      ONLY FOR STUDENTS LOVING THIS KIND OF STUFF (e.g. Linux hackers)

EXERCISE
Explain what you observe when you run this program with and without the option -e.
Then redo the exercise by adding, resp. substracting, four characters in the 
string argument of 'printf("S16>...)'

--------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void empty_printf_buffer()
{ 
   printf("\n... from foo: empty the buffer with a '\\n' character!!! ...\n");
}

int main(int argc, char *argv[])
{
  int status;
  
  printf("\n");
  printf ("S01> 6789 123456789 123456789 123456789 123456789 123456789 123$");
  printf ("S02>                                                           $");
  printf ("S03>  All strings with the prompt 'Sxy>'                       $");
  printf ("S04>     - contain exactly 64 characters                       $");
  printf ("S06>     - contain no end of line character <backslash-n>      $");
  printf ("S05>     - are terminated by the character '$'                 $");
  printf ("S07>                                                           $");
  printf ("S08> ----------------------------------------------------------$");

  if (argc==2) 
    switch (argv[1][1]) {case 'e': empty_printf_buffer();}

  printf ("S09>                                                           $");
  printf ("S10>   To visualize the result, the best is to adjust the      $"); 
  printf ("S11>   size of your terminal window to exactly 64 characters   $");
  printf ("S12>                                                           $");
  printf ("S13>   Remark: on Mac OSX 10.4, the default 'printf' buffer    $");
  printf ("S14>   contains 1024 (= 16 * 64) characters.                   $");
  printf ("S15>                                                           $");
  printf ("S16> ----------------------------------------------------------$");

  if (fork () == 0) { // child
    printf ("CHILD'S HELLO\n");
  } else { // parent
    printf ("PARENT'S HELLO before wait\n");
    wait(&status);
    printf ("PARENT'S HELLO after wait\n");
  }
  return 0;
}
