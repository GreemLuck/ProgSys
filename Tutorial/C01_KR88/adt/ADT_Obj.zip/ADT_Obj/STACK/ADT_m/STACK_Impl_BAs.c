/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: BAs_mut v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // malloc, realloc, free
#include <string.h>       // strcpy                                     //---YYY
#include "../MTE/error.h"
#include "../MTE/type_m.h"                                              //---YYY
#include "../ADT/STACK_DT_Specif.h"
#include "../ADT/STACK_SR_Specif.h"

#define STACK_SR_IMPL_VERSION "STACK SR implementation version: BAs_mut v4.1, 10 March 2013"


/*------------------
Private declarations
------------------*/

typedef struct stack_descr_t {
  elt_t *base;       // points to the base elt of the STACK array instance
  long top;          // pseudo pointer referring to the next free entry
  long size;         // 0 <= size <= capacity
  long capacity;     // capacity of the STACK instance, >= 0
  boolean_t mem_av;  // false if no more node can be added to the STACK and true otherwise  //---YYY
  char *buf;         // buffer for next '*elt.data'                     //---YYY
} stack_descr_t;

/*--- sketch of the data structure -------------------------------      //---YYY    
       ---------     ---------------------            ----------------------
       | * | \0|     | * | * | * | * | \0|            | a big empty buffer |
       ---------     ---------------------            ----------------------
         |             |                                |
         |             |                               buf
 --------|-------------|--------------------------
 | *     |     | *     |     |             |
   -----------------------------------------------
   |                               top
  base
------------------------------------------------------------------------------*/


/*----------
Constructors
----------*/


void stack_create(stackt *_s, long capacity)
//------------------------------------------
{
  stack_descr_t *s;
  
  //--- verify precondition
  if (capacity < 0)                                        //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__negative_capacity_is_not_allowed;
    return;
  }      

  //--- possibly find a free place and update descriptor
  s = malloc(sizeof *s);                  // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)

  if (s == NULL)                                           //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory;
    return;
  }
  
  s->base = malloc(capacity * sizeof(elt_t)); // memory allocation: STACK instance
                                              // (is deallocated by stack_destroy)

  if (s->base == NULL && capacity > 0)                     //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory;
    free(s);
    return;
  }

  s->buf = malloc(MTE_MAX_STR_LEN + 1);   // memory allocation: buffer  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY

 if (s->buf == NULL)                             //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    MTE_error = MTE_ERROR_out_of_memory;                                //---YYY
    free(s->base);                                                      //---YYY
    free(s);                                                            //---YYY
    return;                                                        //---YYY
  }                                                                     //---YYY
  
  s->top = 0;
  s->size = 0;
  s->capacity = capacity;
  s->mem_av = TRUE;                                                     //---YYY
  *_s = s;
}


void stack_destroy(stackt *_s)
//----------------------------
{
  stack_descr_t *s = *_s;
  
  while (s->top-- > 0)                                                  //---YYY
    free(s->base[s->top].data); // free dynamic strings                 //---YYY
  
  free(s->base);                                          // free STACK instance
  free(s->buf);                                     // free ADT buffer  //---YYY
  free(s);                                              // free STACK descriptor
  *_s = NULL;                                          // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == s->capacity)                              //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__object_is_full;
    return;
  }

  if (!s->mem_av)                                //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    MTE_error = MTE_ERROR_out_of_memory;                                //---YYY
    return;                                                             //---YYY
  }                                                                     //---YYY

  if (strlen(e->data) > MTE_MAX_STR_LEN)         //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    MTE_error = MTE_ERROR_data_string_length_is_too_long;               //---YYY
    return;                                                             //---YYY
  }                                                                     //---YYY

  //--- copy *e and update descriptor
  elt_t *tmp = &s->base[s->top]; //local 'tmp' to simplify coding       //---YYY
  tmp->key = e->key;                                                    //---YYY
  tmp->data = s->buf;                                                   //---YYY
  strcpy(tmp->data, e->data);                                           //---YYY
  tmp->data = realloc(tmp->data, strlen(tmp->data) + 1);                //---YYY
                // assuming that reducing string length always succeed  //---YYY                 
  ++s->top;
  ++s->size;

  //--- possibly reserve a free place                                   //---YYY
  s->buf = malloc(MTE_MAX_STR_LEN + 1);   // memory allocation: buffer  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY

  if (s->buf == NULL)                            //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    s->mem_av = FALSE;                // used by 'put' and 'is_mem_av'  //---YYY
    //--- error treatment will be made by a coming 'put' call           //---YYY
  }                                                                     //---YYY
}


void stack_get(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0)                                        //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__object_is_empty;
    return;
  }

  //--- update *e and descriptor
  --s->top;
  elt_t *tmp = &s->base[s->top]; // local 'tmp' to simplify coding      //---YYY
  e->key = tmp->key;                                                    //---YYY
  strcpy(e->data, tmp->data);                                           //---YYY  
  --s->size;

  //--- free space and possibly reserve a free place                    //---YYY
  free(tmp->data);                                                      //---YYY

  if (!s->mem_av)                                                       //---YYY
  {                                                                     //---YYY
    s->buf = malloc(MTE_MAX_STR_LEN + 1); // memory allocation: buffer  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY

    if (s->buf != NULL) s->mem_av = TRUE;                               //---YYY
    else                                         //--- ERROR TREATMENT  //---YYY
    {                                                                   //---YYY
      //--- error treatment will be made by a coming 'put' call         //---YYY
    }                                                                   //---YYY
  }                                                                     //---YYY
}


void stack_new_capacity(stackt _s, long nc)
//-----------------------------------------
{
  stack_descr_t *s = _s;
  elt_t *new_base;
  
  //--- verify precondition
  if (nc < 0)                                              //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__negative_capacity_is_not_allowed;
    return;
  } 
  
  if (nc < s->size)                                        //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__new_capacity_is_too_small;
    return;
  }
  
  if (nc == s->capacity) return;                                //--- do nothing
  
  
  //--- possibly reallocate 'base' and update descriptor
  new_base = realloc(s->base, nc*sizeof(elt_t));
                                     //----- memory reallocation: STACK instance                
                                       //----- (is deallocated by stack_destroy)
  
  if (new_base == NULL)                                    //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory;
    return; // all is still in place, nothing has been touched
  }
  
  s->base = new_base;  // possibly new region
  // 's->top' remains unchanged
  // 's->size' remains unchanged 
  s->capacity = nc;
}


/*--------------
Access functions
--------------*/


void stack_consult(stackt _s, elt_t *e)
//-------------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0)                                        //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__object_is_empty;
    return;
  }

  //--- update *e
  e->key = s->base[s->top - 1].key;                                     //---YYY
  strcpy(e->data, s->base[s->top - 1].data);                            //---YYY
}


boolean_t stack_is_empty(stackt _s)
//---------------------------------
{
  stack_descr_t *s = _s;
  return s->size == 0;
}


boolean_t stack_is_full(stackt _s)
//--------------------------------
{
  stack_descr_t *s = _s;
  return s->size == s->capacity;
}


boolean_t stack_is_mem_av(stackt _s)
//----------------------------------
{
  return TRUE;
}


//----- other access functions   -----


boolean_t stack_exists(stackt _s)
//-------------------------------
{
  return _s != NULL;
}


long stack_size(stackt _s)
//------------------------
{
  stack_descr_t *s = _s;
  return s->size;
}


long stack_capacity(stackt _s)
//----------------------------
{
  stack_descr_t *s = _s;
  return s->capacity;
}


char *stack_impl_version() 
//------------------------
{
  return STACK_SR_IMPL_VERSION;
}


char *stack_impl_type() 
//---------------------
{
  return "BAs_mut";                                                     //---YYY
}


/*---------------
Traverse function
---------------*/


void stack_traverse(stackt _s, void fct(buf_t *), buf_t *buf)
//-----------------------------------------------------------
{
  stack_descr_t *s = _s;
  long tmp = s->top;
  
  while (tmp != 0) {
    buf->elt1 = &s->base[--tmp];
    fct(buf);
  }
}
