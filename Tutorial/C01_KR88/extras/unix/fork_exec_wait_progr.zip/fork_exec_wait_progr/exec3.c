/*--------------------------------------------------------------------------------
Title: Program overlay - a variant 
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 2006

DESCRIPTION
Similar to 'exec2.c' program. Advanced version.

USAGE
exec3  prog_name [options]
   (where 'prog_name' is the name of a program in the search path $PATH or 
   'prog_name' contains the full pathname)
   
EXAMPLE
% exec3 ls -l -a  // List the files in the current directory with options -l -a

EXERCISE
% exec3 exec3 exec3 ls -a  // What happens? Explain and verify on machine
--------------------------------------------------------------------------------*/

#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) 
{
  char *argp[10];
  int i;
  
  // exit upon input error
  if (argc < 2) {
    printf("usage: exec3 prog_name [-options]\n");
    return -1;
  }
	
  // 'argp' initialization
  for (i=0; argv[i] != NULL; i++)
    argp[i] = argv[i+1];
  argp[i] = NULL;
 
  // Display of the command to be launched
  printf("> Execute the command ' ");
  for (i=0; argp[i] != NULL; i++)
    printf("%s ", argp[i]);
  printf("' with execvp\n");

  execvp(argp[0],argp);  // the new command is launched
  
  printf("> Couldn't execute '%s'\n", argp[0]);
  return 0;
}
