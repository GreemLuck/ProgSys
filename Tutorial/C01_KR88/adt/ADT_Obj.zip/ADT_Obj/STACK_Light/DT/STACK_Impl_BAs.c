/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: BAs v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // malloc, realloc, free
#include "../MTE/type_f.h"
#include "../DT/STACK_DT_Specif_BAs.h"                                  //---YYY
#include "../DT/STACK_SR_Specif.h"                                      //---YYY


/*------------------
Private declarations
------------------*/

/*----------------------------------------------                        //---YYY
typedef struct stack_descr_t {
  elt_t *base;    // points to the base elt of the STACK array instance
  long top;       // pseudo pointer referring to the next free entry
  long size;      // 0 <= size <= capacity
  long capacity;  // capacity of the STACK instance, >= 0
} stack_descr_t;
----------------------------------------------*/                        //---YYY

/*--- sketch of the data structure ---------
           -----------------------------
           | * | * | * | * |   |   |   | 
           ----------------------------- 
             |              top
            base
------------------------------------------*/


/*----------
Constructors
----------*/


void stack_create(stackt *s, long capacity)
//-----------------------------------------
{
  // stack_descr_t *s;                                                  //---YYY
  
  //--- verify precondition
  if (capacity < 0) exit(EXIT_FAILURE); // negative capacity is not allowed

  //--- possibly find a free place and update descriptor

  /*----- suppress: memory for stack descriptor is already allocated by user program //---YYY
  s = malloc(sizeof *s);                  // memory allocation: STACK descriptor     //---YYY
                                            // (is deallocated by stack_destroy)     //---YYY

  if (s == NULL)                                           //--- ERROR TREATMENT     //---YYY
  {                                                                                  //---YYY
    MTE_error = MTE_ERROR_out_of_memory;                                             //---YYY
    return;                                                                          //---YYY
  }                                                                                  //---YYY
  -----*/                                                                            //---YYY
  
  s->base = malloc(capacity * sizeof(elt_t)); // memory allocation: STACK instance
                                              // (is deallocated by stack_destroy)
  
  s->top = 0;
  s->size = 0;
  s->capacity = capacity;
  // *_s = s;                                                          ///---YYY
}


void stack_destroy(stackt *s)
//---------------------------
{
  free(s->base);                                          // free STACK instance
  s->base = NULL;  // otherwise the behaviour iss unpredictable         //---YYY
  
  s->top = 0;  // for coherence reaon, not mandatory                    //---YYY
  s->size = 0; // for coherence reaon, not mandatory                    //---YYY

  // free(s);                                 // free STACK descriptor  //---YYY
  // *_s = NULL;                             // STACK no longer exists  //---YYY
}


/*----------
Manipulators
----------*/


void stack_put(stackt *s, elt_t *e)
//---------------------------------
{
  //--- verify precondition
  if (s->size == s->capacity) exit(EXIT_FAILURE); // stack is full

  //--- copy *e and update descriptor
  s->base[s->top] = *e;
  ++s->top;
  ++s->size;
}


void stack_get(stackt *s, elt_t *e)
//---------------------------------
{
  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e and descriptor
  --s->top;
  *e = s->base[s->top];
  --s->size;
}


/*--------------
Access functions
--------------*/


void stack_consult(stackt s, elt_t *e)
//------------------------------------
{
  //--- verify precondition
  if (s.size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e
  *e = s.base[s.top - 1];
}


boolean_t stack_is_empty(stackt s)
//--------------------------------
{
  return s.size == 0;
}


boolean_t stack_is_full(stackt s)
//-------------------------------
{
  return s.size == s.capacity;
}


boolean_t stack_is_mem_av(stackt s)
//---------------------------------
{
  return TRUE;
}


/*---------------
Traverse function
---------------*/


void stack_traverse(stackt s, void fct(buf_t *), buf_t *buf)
//----------------------------------------------------------
{
  long tmp = s.top;
  
  while (tmp != 0) {
    buf->elt1 = &s.base[--tmp];
    fct(buf);
  }
}
