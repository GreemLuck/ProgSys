/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: UAn v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // malloc, realloc, free
#include "../MTE/type_f.h"
#include "../ADT/STACK_DT_Specif.h"
#include "../ADT/STACK_SR_Specif.h"

#define STACK_SR_IMPL_VERSION "STACK SR implementation version: UAn v4.1, 10 March 2013"


/*------------------
Private declarations
------------------*/

typedef struct stack_descr_t {
  elt_t *base;       // points to the base elt of the STACK array instance
  long top;          // pseudo pointer referring to the next free entry
  long size;         // 0 <= size <= capacity
  long capacity;     // current capacity of the STACK instance, >= 0
  long init_cap;     // initial capacity, >= 0
  long incr;         // increment, > 1
} stack_descr_t;

/*--- sketch of the data structure ---------
           -----------------------------
           | * | * | * | * |   |   |   | 
           ----------------------------- 
             |              top
            base
------------------------------------------*/


/*----------
Constructors
----------*/


void stack_create(stackt *_s, long capacity)
//------------------------------------------
{
  stack_descr_t *s;
  
  //--- verify precondition
  if (capacity < 0) exit(EXIT_FAILURE); // negative capacity is not allowed

  //--- possibly find a free place and update descriptor
  s = malloc(sizeof *s);                  // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)
  
  s->base = malloc(capacity * sizeof(elt_t)); // memory allocation: STACK instance
                                              // (is deallocated by stack_destroy)
  
  s->top = 0;
  s->size = 0;
  s->capacity = capacity;
  s->init_cap = capacity;
  if (capacity == 0) s->incr = 1; else s->incr = capacity;
  *_s = s;
}


void stack_destroy(stackt *_s)
//----------------------------
{
  stack_descr_t *s = *_s;
  
  free(s->base);                                          // free STACK instance
  free(s);                                              // free STACK descriptor
  *_s = NULL;                                          // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- possibly find a free place
  if (s->size == s->capacity) // no more free slots are available
  {
    elt_t *new_base = realloc(s->base, (s->capacity + s->incr)*sizeof(elt_t));
                                          // memory reallocation: STACK instance
                                            // (is deallocated by stack_destroy)
    
    s->base = new_base;  // possibly new region
    s->capacity = s->capacity + s->incr;
  }
  
  //--- copy *e and update descriptor
  s->base[s->top] = *e;
  ++s->top;
  ++s->size;
}


void stack_get(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e and descriptor
  --s->top;
  *e = s->base[s->top];
  --s->size;
  
  //--- possibly free space 
  if (s->capacity - s->init_cap > s->size)
  {
    s->base = realloc(s->base, (s->capacity - s->incr)*sizeof(elt_t));
                    // assuming that reducing an allocated region always succeed                
    s->capacity = s->capacity - s->incr;
  }   
}


/*--------------
Access functions
--------------*/


void stack_consult(stackt _s, elt_t *e)
//-------------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e
  *e = s->base[s->top - 1];
}


boolean_t stack_is_empty(stackt _s)
//---------------------------------
{
  stack_descr_t *s = _s;
  return s->size == 0;
}


boolean_t stack_is_full(stackt _s)
//--------------------------------
{
  return FALSE;
}


boolean_t stack_is_mem_av(stackt _s)
//----------------------------------
{
  return TRUE;
}


/*---------------
Traverse function
---------------*/


void stack_traverse(stackt _s, void fct(buf_t *), buf_t *buf)
//-----------------------------------------------------------
{
  stack_descr_t *s = _s;
  long tmp = s->top;
  
  while (tmp != 0) {
    buf->elt1 = &s->base[--tmp];
    fct(buf);
  }
}
