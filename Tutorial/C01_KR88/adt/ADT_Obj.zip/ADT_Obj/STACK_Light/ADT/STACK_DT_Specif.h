/*--------------------------------------------------------------------------------
STACK data type specification
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: ADT v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#ifndef _STACK_SPECIF_ADT_H
#define  _STACK_SPECIF_ADT_H

typedef void *stackt;  // 'stack_t' is already defined in '_structs.h'

#endif /*  _STACK_SPECIF_ADT_H */