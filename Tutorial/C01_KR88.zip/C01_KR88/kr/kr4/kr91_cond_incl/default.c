#include <stdio.h>

void printsys(void){
	printf("default system\n");
}
