#include "tellMe.h"

main()
{
    tellMe("Hello World");
}
