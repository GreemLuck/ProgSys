/*--------------------------------------------------------------------------------
STACK data type specification
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: DT_BAs v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#ifndef _STACK_SPECIF_DT_BAs_H
#define _STACK_SPECIF_DT_BAs_H

typedef struct stack_descr_t {
  elt_t *base;    // points to the base elt of the STACK array instance
  long top;       // pseudo pointer refering to the next free entry
  long size;      // 0 <= size <= capacity
  long capacity;  // capacity of the STACK instance, >= 0
} stack_descr_t;

typedef stack_descr_t stackt;  // 'stack_t' is already defined in '_structs.h'  //---YYY

#endif /* _STACK_SPECIF_DT_BAs_H */