/*--------------------------------------------------------------------------------
Title: Simple test program
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland
Version: version 1, 9 September 2007, rev. 31 Jan. 2015

Description: Read from the standard input a key (integer) and a word (C string) 
and print them.

Usage: prog_name

Comment: This program prints garbage data if an input format error occurs.
--------------------------------------------------------------------------------*/

#include <stdio.h>

int main() {
  int key;
  char word[20];

  printf("> enter an integer followed by a string\n");
  scanf("%d %s", &key, word);  // Read the data
  
  // Do some action (here nothing is done)
	  
  printf("%d %s\n", key, word);  // Print the result
}