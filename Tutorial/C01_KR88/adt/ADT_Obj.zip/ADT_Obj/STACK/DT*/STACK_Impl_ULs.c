/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: ULs v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // malloc, realloc, free
#include "../MTE/error.h"
#include "../MTE/type_f.h"
#include "../DT*/STACK_DT_Specif_ULs.h"                                 //---YYY
#include "../ADT/STACK_SR_Specif.h"

#define STACK_SR_IMPL_VERSION "STACK SR implementation version: ULs v4.1, 10 March 2013"


/*------------------
Private declarations
------------------*/

/*----------------------------------------------                        //---YYY
typedef struct p_node_t {  // node of a 'simple linked' predecessor list
  elt_t e;                 // element to be stored in a node
  struct p_node_t *pred;   // points to the predecessor node
} p_node_t;

typedef struct stack_descr_t {
  p_node_t *top;     // points to the top node, i.e. last in element
  long size;         // number of elements in the STACK
  boolean_t mem_av;  // false if no more node can be added to the STACK and true otherwise
  p_node_t *buf;     // buffer for a new node
} stack_descr_t;
----------------------------------------------*/                        //---YYY

/*--- sketch of the data structure ------------

         /---|*| <---|*| <---|*|      /---| |
                 pred         |            |
                             top          buf
---------------------------------------------*/


/*----------
Constructors
----------*/


void stack_create(stackt *_s, long cap)
//------------------------------------- 'cap' is not used for UL implementation
{
  //--- possibly find a free place and update descriptor
  stack_descr_t *s = malloc(sizeof *s);   // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)

  if (s == NULL)                                           //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory;
    return;
  }

  p_node_t *b = malloc(sizeof *b);            // memory allocation: STACK buffer
                                            // (is deallocated by stack_destroy)

  if (b == NULL)                                           //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory;
    free(s);
    return;
  }

  s->top = NULL;
  s->size = 0;
  s->mem_av = TRUE;
  s->buf = b;
  *_s = s;
}


void stack_destroy(stackt *_s)
//----------------------------
{
  stack_descr_t *s = *_s;
  p_node_t *tmp = s->top;
  
  while (tmp != NULL) 
  {s->top = tmp->pred; free(tmp); tmp = s->top;}          // free STACK instance

  if (s->buf != NULL) free(s->buf);                               // free buffer
  free(s);                                              // free STACK descriptor
  *_s = NULL;                                          // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (!s->mem_av)                                          //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory; 
    return; 
  }

  //--- copy *e and update descriptor
  s->buf->e = *e;
  s->buf->pred = s->top;
  
  s->top = s->buf;
  ++s->size; 
  
  //--- possibly reserve a free place
  s->buf = malloc(sizeof *s->buf);            // memory allocation: STACK buffer
                               // (is deallocated by stack_destroy or stack_get)
  
  if (s->buf == NULL)                                      //--- ERROR TREATMENT
  {
    s->mem_av = FALSE;                          // used by 'put' and 'is_mem_av'
    //--- error treatment will be made by a coming 'put' call
  }
}


void stack_get(stackt _s,  elt_t *e)
//----------------------------------
{
  stack_descr_t *s = _s;
  p_node_t *tmp = s->top;

  //--- verify precondition
  if (tmp == NULL)                                         //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__object_is_empty;
    return;
  }
  
  //--- update *e and descriptor
  *e = tmp->e;

  s->top = tmp->pred;
  --s->size;

  //--- free space or update free place and set 'mem_av' to TRUE
  if (s->mem_av) free(tmp);                             // free the old top node
  else {s->buf = tmp; s->mem_av = TRUE;}   // give this place back to the buffer
}


void stack_new_capacity(stackt _s, long nc)
//-----------------------------------------
{
  // do nothing, capacity is not used for UL implementations
}


/*--------------
Access functions
--------------*/


void stack_consult(stackt _s,  elt_t *e)
//--------------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0)                                        //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__object_is_empty;
    return;
  }
  
  //--- update *e
  *e = s->top->e;
}


boolean_t stack_is_empty(stackt _s)
//---------------------------------
{
  stack_descr_t *s = _s;
  return s->top == NULL;
}


boolean_t stack_is_full(stackt _s)
//--------------------------------
{
  return FALSE;
}


boolean_t stack_is_mem_av(stackt _s)
//----------------------------------
{
  stack_descr_t *s = _s;
  return s->mem_av;
}


//----- other access functions   -----


boolean_t stack_exists(stackt _s)
//-------------------------------
{
  return _s != NULL;
}


long stack_size(stackt _s)
//------------------------
{
  stack_descr_t *s = _s;
  return s->size;
}


long stack_capacity(stackt _s)
//----------------------------
{
  return CAP_UL;
}


char *stack_impl_version() 
//------------------------
{
  return STACK_SR_IMPL_VERSION;
}


char *stack_impl_type() 
//---------------------
{
  return "ULs";
}


/*---------------
Traverse function
---------------*/


void stack_traverse(stackt _s, void fct(buf_t *), buf_t *buf)
//-----------------------------------------------------------
{
  stack_descr_t *s = _s;
  p_node_t *tmp = s->top;
  
  while (tmp != NULL) {
    buf->elt1 = &tmp->e;
    fct(buf);
    tmp = tmp->pred;
  }
}
