main()
{
  int *p;  // p is uninitialized and points
           // to a random location in memory!
  *p = 12;
}
