/*-----------------------------------------------------------------------------
Short description: My second thread program: ping-pong revisited.

Description: Each thread displays a ping or PONG every ms milliseconds and counts
how many ping or PONG he displayed. The program illustrates how to:

   - define and use shared data structures and variables
   - pass a data structure to a thread
   - synchronize with the calling thread
   - return a data structure to the calling thread

   - stop a program by hitting a key

Remark: you can run this program in two modes: verbose or unverbose. In verbose
mode, miscellaneous addresses, sizes and values are displyed; this mode allows
to verify that all is working fine and gives also an inside to the different
memory segments: common heap, threads' stack, ...

Usage:   progr_name <u|v> <ms>  (quit by hitting a key)

Example: progr_name u 10  (unverbose mode, each child thread goes to sleep at every loop for 10 msec)
         progr_name v  0  (verbose mode each child thread calls 'sched_yield()' at every loop)

Author: Beat Hirsbrunner
Version 1.0: 31 December 2008 / rev. 29 March 09, 3 December 09
Version 2.0: 10 Deccember 2011
-----------------------------------------------------------------------------*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>    // EXIT_SUCCESS, malloc, free
#include <string.h>    // strlen
#include <unistd.h>    // sleep, usleep

#include "silent_getchar.c" // silent_getchar


/*---------------------------------------------------*/
/*-----   Shared data structure and variables   -----*/
/*---------------------------------------------------*/
typedef struct pthread_data_t
{
   int   tid;   // pThread IDentifier
   char  *mssg;
   long  buf;   // a buffer allowing the called thread to return some results
} pthread_data_t;

typedef struct pthread_result_t
{
   long  i;
   char  *mssg;
} pthread_result_t;

int ms;  // passive waiting of ms millisecond before writing a ping or pong

int kb_hit = 0; // continuously read by the pthreads, and written to 1 (true)
                // by the main thread to indicate to all pthreads to terminate

char verbose = 'u';  // used to display verbose (='v') or non verbose (!='v') infos


/*-------------------------------*/
/*-----   Thread function   -----*/
/*-------------------------------*/
void *display(void *arg)
{
   pthread_data_t *data  = arg;                 // implicit cast of void pointer 'arg'
   pthread_result_t *res = malloc(sizeof *res); // implicit cast of void *
   long n = 0;

   /*-----   main loop   -----*/
   while(!kb_hit) { // exit the loop once kb_hit has been set to 1 by the main thread
      ++n;
      printf("%s ", data->mssg);
      fflush(stdout);
      usleep(ms*1000);
      if (ms==0) sched_yield();  // yield the processor to another thread
                                 // only if this has not yet been done by usleep
   }

   /*-----   Termination   -----*/
   data->buf = n;  // transmit infos to the calling thread via the calling parameter 'arg'

   res->i = n;     // another way to transmit infos to the calling thread via pthread_exit()
   if (data->tid % 2)
      res->mssg = "BLONG";
   else
      res->mssg = "bling";

   printf("\n");
   if (verbose=='v') {
      printf("verbose from thread %i (%s) about 'res' and 'res->mssg'\n   --- Size in byte: %lu  %lu\n   --- Addresses: %lu  %lu \n",
             data->tid, data->mssg,
             sizeof res, strlen(res->mssg),
             (long unsigned) &res, (long unsigned) &((res->mssg)[0]));
   }
   printf("Bye bye from thread %i (%s):  n=%li\n", data->tid, data->mssg, n);

   pthread_exit(res);
}


/*-----------------------------*/
/*-----   main function   -----*/
/*-----------------------------*/
int main(int argc, char **argv)
{
   pthread_t         thread[2];
   pthread_data_t    data[2] = { {0,"ping",0}, {1,"PONG",0} };
   pthread_result_t  *res[2] = {NULL, NULL};

   if (argc != 3) {
	   fprintf(stderr, "-----Usage: %s <u|v> <ms>  (quit by hitting a key)\n", argv[0]);
	   exit(-1);
	}

   printf("quit by hitting a key\n");

   /*-----   Initialization   -----*/
   verbose = argv[1][0];
   ms = atoi(argv[2]);    // in msec


   /*-----   Create two threads   -----*/
   pthread_create(&thread[0], NULL, display, &data[0]);
   // sleep(1); // wait one second before launching the 2nd thread, just for fun
   pthread_create(&thread[1], NULL, display, &data[1]);

   /*-----   Wait until a key is pressed   -----*/
   silent_getchar();
   kb_hit = 1;

   /*-----   Wait the exit of the two created threads   -----*/
   pthread_join(thread[0], (void **) &res[0]);
   pthread_join(thread[1], (void **) &res[1]);


   /*-----   Termination   -----*/
   if (verbose == 'v') {
      printf("\nverbose from thread main about 'res[0]' and 'res[0]->mssg'\n   --- Size in byte: %lu  %lu\n   --- Addresses: %lu  %lu\n",
             sizeof res[0], strlen(res[0]->mssg),
             (long unsigned) &res[0], (long unsigned) &((res[0]->mssg)[0]));
      printf("\nverbose from thread main about 'res[1]' and 'res[1]->mssg'\n   --- Size in byte: %lu  %lu\n   --- Addresses: %lu  %lu\n",
             sizeof res[1], strlen(res[1]->mssg),
             (long unsigned) &res[1], (long unsigned) &((res[1]->mssg)[0]));

      printf("\nverbose from thread main\n");
      printf("   --- data[0]: tid=%d, mssg=%s, buf=%li\n", data[0].tid, data[0].mssg, data[0].buf);
      printf("   --- data[1]: tid=%d, mssg=%s, buf=%li\n", data[1].tid, data[1].mssg, data[1].buf);

      printf("   --- res[0]:         mssg=%s,  i=%li\n", res[0]->mssg, res[0]->i);
      printf("   --- res[1]:         mssg=%s,  i=%li\n", res[1]->mssg, res[1]->i);
   }


   printf("Bye bye from thread main: n0=%li, n1=%li \n", res[0]->i, res[1]->i);

   free(res[0]);  // deallocate memory allocated by the two child threads !
   free(res[1]);

   return (EXIT_SUCCESS);
}
