/*--------------------------------------------------------------------------------
STACK data type specification
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: ADT v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#ifndef _STACK_SPECIF_ADT_H
#define  _STACK_SPECIF_ADT_H

#define STACK_DT_SPECIF_VERSION "STACK DT specification version : ADT v4.1, 10 March 2013"

typedef void *stackt;  // 'stack_t' is already defined in '_structs.h'

#endif /*  _STACK_SPECIF_ADT_H */