/*--------------------------------------------------------------------------------
Title: Simple test program with error treatment
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland
Version: version 1, 9 September 2007

Description: Read from the standard input a list of keys (integer) until EOF is 
encountered, do some action on the readed data (e.g. do nothing!), and print
the result, one key per line. Some lines may contain misformatted data; in this 
case the rest of the line is skipped.

Comment: This program will loop forever if an input format error occurs, since 
the next call to scanf resumes searching immediately after the last character 
already converted! The program will be trapped inside the while loop!
--------------------------------------------------------------------------------*/

#include <stdio.h>

int main() {
  int i, max=0, key[1000];

  while (scanf("%d", &key[max++]) != EOF) ; // Read the data
  --max; // max has also been incremented when scanf has encountered EOF !
  
  // Do some action (here do nothing!)
 
  // Print the result
  printf("-----\n");
  for (i=0; i<max; ++i) printf("%d\n", key[i]);
}