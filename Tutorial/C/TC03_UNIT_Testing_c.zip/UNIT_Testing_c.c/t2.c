/*--------------------------------------------------------------------------------
Title: Simple test program
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland
Version: version 1, 9 September 2007

Description: Read from the standard input a list of keys (integer) and words, and 
print them, until EOF is encountered.

Usage: prog_name  

Comment: This program will loop forever if an input format error occurs.
Hint: In the present case scanf() reads an integer (which may fail) and then a 
word (which never fails). As scanf() resumes at the misformatted data, this same
data will be read again and again.

Exercise: Try out what happens if you invert the reading order: first a word and 
then an integer. Try that with repeated input errors (e.g. enter the input 
'hello 1', 'hi bye', 'good well', 'strange 2'). Explain.
--------------------------------------------------------------------------------*/

#include <stdio.h>

int main() {
  int key;
  char word[20];

  // --------------------------------------------------------------
  while (scanf("%d %s", &key, word) != EOF) { // Read the next data
    
	// Do some action (here nothing is done)

	printf("%d %s\n", key, word);  // Print the result
  }
  // --------------------------------------------------------------
}