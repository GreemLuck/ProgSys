void inc (int *i) 
{
  ++*i;
}

main(){
  int i=1;
  inc(i);  // instead of inc(&i)
}




