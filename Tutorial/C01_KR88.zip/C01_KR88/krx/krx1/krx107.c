/* Author: Richard Heathfield */

#include <stdio.h>

int main(void)
{
  printf("The value of EOF is %d\n\n", EOF);
  
  return 0;
}


