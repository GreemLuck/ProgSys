/*--------------------------------------------------------------------------------
FIFO subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: UL v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // exit, malloc, free
#include "FIFO_SR_Specif.h"


/*--- sketch of the data structure ------------

         |*|---> |*|---> |*|---/  
          | succ          |
         head            tail
---------------------------------------------*/


//--- data type
typedef struct s_node_t {  // node of a 'simple linked' successor list
  int e;                   // element to be stored in a node
  struct s_node_t *succ;   // points to the successor node
} s_node_t;


//--- shared variable
static s_node_t *head = NULL;
static s_node_t *tail = NULL;


//--- fifo subroutines
void fifo_put(int e)
{
  s_node_t *tmp = malloc(sizeof *tmp);           // memory allocation: next node
                                                      // (is deallocated by get)

  tmp->e = e;
  tmp->succ = NULL;
  
  if (head == NULL) head = tmp;
  if (tail != NULL) tail->succ = tmp;
  tail = tmp;
}

int fifo_get()
{
  if (head == NULL) exit(EXIT_FAILURE); // fifo is empty

  s_node_t *tmp = head;  // local variable 'tmp' points to head-pre node
  int e = tmp->e;        // head element to be returned
  
  head = tmp->succ;               // update shared 'head'
  if (head == NULL) tail = NULL;  // possibly update 'tail'
  free(tmp);                      // free the space of the head-pre node

  return e; // return head-pre element
}