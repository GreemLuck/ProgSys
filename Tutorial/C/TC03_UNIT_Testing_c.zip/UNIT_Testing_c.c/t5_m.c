/*----------------------------------------------------------------------------
Manual Program Testing : a very simple example

Usage: 
   t5_m               //--- Interactive mode
                      //--- Type a character after the display of the prompt '>'
   t5_m > res_mi.txt  //--- Dito

   t5_m < t5.txt                //--- Batch mode
   t5_m < t5.txt  > res_mb.txt  //--- Dito

Beat Hirsbrunner, 1 September 2011
----------------------------------------------------------------------------*/
#include <stdio.h>

char f(char c) { return c; }      // a potential existing implementation
char my_f(char c) { return c; }   // a potential new implementation

int main() {
   char c;
     
   fprintf(stderr,">");
   while ( (c=getchar()) != EOF ) {
      printf("%c, %c, %c\n", c, my_f(c), f(c));  //--- output for manual checking
      while (getchar() != '\n') {} // skip end of line
      fprintf(stderr,">");
   }
   fprintf(stderr,"\n");
   
   return 0;
}