/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: BAs_mut v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // malloc, realloc, free
#include <string.h>       // strcpy                                     //---YYY
#include "../MTE/type_m.h"                                              //---YYY
#include "../ADT/STACK_DT_Specif.h"
#include "../ADT/STACK_SR_Specif.h"


/*------------------
Private declarations
------------------*/

typedef struct stack_descr_t {
  elt_t *base;       // points to the base elt of the STACK array instance
  long top;          // pseudo pointer referring to the next free entry
  long size;         // 0 <= size <= capacity
  long capacity;     // capacity of the STACK instance, >= 0
  boolean_t mem_av;  // false if no more node can be added to the STACK and true otherwise  //---YYY
  char *buf;         // buffer for next '*elt.data'                     //---YYY
} stack_descr_t;

/*--- sketch of the data structure -------------------------------      //---YYY    
       ---------     ---------------------            ----------------------
       | * | \0|     | * | * | * | * | \0|            | a big empty buffer |
       ---------     ---------------------            ----------------------
         |             |                                |
         |             |                               buf
 --------|-------------|--------------------------
 | *     |     | *     |     |             |
   -----------------------------------------------
   |                               top
  base
------------------------------------------------------------------------------*/


/*----------
Constructors
----------*/


void stack_create(stackt *_s, long capacity)
//------------------------------------------
{
  stack_descr_t *s;
  
  //--- verify precondition
  if (capacity < 0) exit(EXIT_FAILURE); // negative capacity is not allowed

  //--- possibly find a free place and update descriptor
  s = malloc(sizeof *s);                  // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)
  
  s->base = malloc(capacity * sizeof(elt_t)); // memory allocation: STACK instance
                                              // (is deallocated by stack_destroy)

  s->buf = malloc(MTE_MAX_STR_LEN + 1);   // memory allocation: buffer  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY
  
  s->top = 0;
  s->size = 0;
  s->capacity = capacity;
  s->mem_av = TRUE;                                                     //---YYY
  *_s = s;
}


void stack_destroy(stackt *_s)
//----------------------------
{
  stack_descr_t *s = *_s;
  
  while (s->top-- > 0)                                                  //---YYY
    free(s->base[s->top].data); // free dynamic strings                 //---YYY
  
  free(s->base);                                          // free STACK instance
  free(s->buf);                                     // free ADT buffer  //---YYY
  free(s);                                              // free STACK descriptor
  *_s = NULL;                                          // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == s->capacity) exit(EXIT_FAILURE); // stack is full

  if (!s->mem_av) exit(EXIT_FAILURE); // out of memory                  //---YYY

  if (strlen(e->data) > MTE_MAX_STR_LEN) exit(EXIT_FAILURE);            //---YYY
                                      // data string length is too long //---YYY

  //--- copy *e and update descriptor
  elt_t *tmp = &s->base[s->top]; //local 'tmp' to simplify coding       //---YYY
  tmp->key = e->key;                                                    //---YYY
  tmp->data = s->buf;                                                   //---YYY
  strcpy(tmp->data, e->data);                                           //---YYY
  tmp->data = realloc(tmp->data, strlen(tmp->data) + 1);                //---YYY
                // assuming that reducing string length always succeed  //---YYY                 
  ++s->top;
  ++s->size;

  //--- possibly reserve a free place                                   //---YYY
  s->buf = malloc(MTE_MAX_STR_LEN + 1);   // memory allocation: buffer  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY

  if (s->buf == NULL)                            //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    s->mem_av = FALSE;                // used by 'put' and 'is_mem_av'  //---YYY
    //--- error treatment will be made by a coming 'put' call           //---YYY
  }                                                                     //---YYY
}


void stack_get(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e and descriptor
  --s->top;
  elt_t *tmp = &s->base[s->top]; // local 'tmp' to simplify coding      //---YYY
  e->key = tmp->key;                                                    //---YYY
  strcpy(e->data, tmp->data);                                           //---YYY  
  --s->size;

  //--- free space and possibly reserve a free place                    //---YYY
  free(tmp->data);                                                      //---YYY

  if (!s->mem_av)                                                       //---YYY
  {                                                                     //---YYY
    s->buf = malloc(MTE_MAX_STR_LEN + 1); // memory allocation: buffer  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY

    if (s->buf != NULL) s->mem_av = TRUE;                               //---YYY
    else                                         //--- ERROR TREATMENT  //---YYY
    {                                                                   //---YYY
      //--- error treatment will be made by a coming 'put' call         //---YYY
    }                                                                   //---YYY
  }                                                                     //---YYY
}


/*--------------
Access functions
--------------*/


void stack_consult(stackt _s, elt_t *e)
//-------------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e
  e->key = s->base[s->top - 1].key;                                     //---YYY
  strcpy(e->data, s->base[s->top - 1].data);                            //---YYY
}


boolean_t stack_is_empty(stackt _s)
//---------------------------------
{
  stack_descr_t *s = _s;
  return s->size == 0;
}


boolean_t stack_is_full(stackt _s)
//--------------------------------
{
  stack_descr_t *s = _s;
  return s->size == s->capacity;
}


boolean_t stack_is_mem_av(stackt _s)
//----------------------------------
{
  return TRUE;
}


/*---------------
Traverse function
---------------*/


void stack_traverse(stackt _s, void fct(buf_t *), buf_t *buf)
//-----------------------------------------------------------
{
  stack_descr_t *s = _s;
  long tmp = s->top;
  
  while (tmp != 0) {
    buf->elt1 = &s->base[--tmp];
    fct(buf);
  }
}
