/*--------------------------------------------------------------------------------
STACK data type specification
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: DT_ULs v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#ifndef _STACK_SPECIF_DT_ULs_H
#define _STACK_SPECIF_DT_ULs_H

typedef struct p_node_t {  // node of a 'simple linked' predecessor list
  elt_t e;                 // element to be stored in a node
  struct p_node_t *pred;   // points to the predecessor node
} p_node_t;

typedef struct stack_descr_t {
  p_node_t *top;     // points to the top node, i.e. last in element
  long size;         // number of elements in the STACK
  boolean_t mem_av;  // false if no more node can be added to the STACK and true otherwise
  p_node_t *buf;     // buffer for a new node
} stack_descr_t;

typedef stack_descr_t stackt;  // 'stack_t' is already defined in '_structs.h'  //---YYY

#endif /* _STACK_SPECIF_DT_ULs_H */