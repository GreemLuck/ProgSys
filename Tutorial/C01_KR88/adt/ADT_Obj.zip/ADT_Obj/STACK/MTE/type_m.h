/*--------------------------------------------------------------------------------
Header file of types and constants used in the Mini Test Environment (MTE)
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: 4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#ifndef _MTE_TYPE_H
#define _MTE_TYPE_H


// Constants
//----------
#define CAP_UL -1  // 'capacity' value for unbounded linked list implementations
#define MTE_MAX_STR_LEN (1024 - sizeof(long) - 1) // maximum string length


// Boolean type
//-------------
typedef enum boolean_t {FALSE, TRUE} boolean_t;


// Data string buffer type
//------------------------
typedef char data_t[MTE_MAX_STR_LEN + 1];


// Element types
//--------------
#define __fixed_data_length__    0
#define __mutable_data_length__  1

typedef struct elt_t {  // 1K = 2**10 bytes for static string length
  long key;
//data_t data;  // fixed string length                                  //---YYY
  char *data;   // mutable string length                                //---YYY
} elt_t;

typedef struct buf_t { // a buffer type used by ADT traverse
  elt_t *elt1;  // address of an element *elt1 of the visited ADT
  elt_t *elt2;  // address of a user supplied element *elt2
  void  *res;   // address of a possibe result *res computed by a user supplied fct
} buf_t;

#endif /* _MTE_TYPE_H */
