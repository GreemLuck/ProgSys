/*--------------------------------------------------------------------------------
Title: Process creation (visit 2)
Author: B. Hirsbrunner, University of Fribourg, June 2006, rev. Nov. 2010, Dec. 11

DESCRIPTION
Similar to 'fork1.c' program, augmented by 'process id' information

USAGE
% fork2

EXERCISE
1. Explain what happens and verify your answer on machine.

2. Run this program several times and observe ppid's value of the child process.
In some cases this value is rather strange! Why? 

Answer: A parent process may finish before their children. In this case the value 
of the parent process identifier (ppid) is equal 1, i.e. the parent process has 
been replaced by a so called zombie process, with pid 1.

Don't hesitate to google 'unix zombie'.
--------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() 
{
  int fork_pid;
  printf("> Before                  :  ppid=%i  pid=%i\n", getppid(), getpid());
  
  fork_pid = fork();
  
  if (fork_pid != 0) {  // parent process
    printf("> After, from parent prcss:  ppid=%i  pid=%i  fork_pid=%i\n", getppid(), getpid(), fork_pid);
  } else {  
    printf("> After, from child prcss :  ppid=%i  pid=%i  fork_pid=%i\n", getppid(), getpid(), fork_pid);
  }
  return 0;
}
