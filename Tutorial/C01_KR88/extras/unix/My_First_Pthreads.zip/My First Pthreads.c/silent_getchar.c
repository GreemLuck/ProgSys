/*-----------------------------------------------------------------------------
Description: a silent getchar, i.e. without echo and input buffering
Tested: on OSX 10.5 and Ubuntu 9
Authors: Beat Hirsbrunner and Mario Sitz, Univerity of Fribourg, Switzerland
Version: 0.9, 27 March 2009
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <termios.h>  //  struct termios, tcgetattr, tcsetattr


void silent_getchar() {
    static const int STDIN = 0;
    struct termios term, term_safe;
        
    tcgetattr(STDIN, &term);
    term_safe = term;

    term.c_lflag &= ECHOK;              // echo off (and no input buffering !!!)
    // term.c_iflag &= ISTRIP;          // strip character
    tcsetattr(STDIN, TCSANOW, &term);   // TCSANOW: change attributes immediately

    getchar(); // wait passively until a character is available on the stdin stream    

    tcsetattr(STDIN, TCSANOW, &term_safe); // reset initial settings
}


/*----- Test program -----
main() {
   printf("Hello: just hit a key!!!\n");
   silent_getchar();  // Hit any character
   printf("Bye bye\n");
}
-----*/