/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: ULn v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // exit, malloc, realloc, free
#include "../MTE/type_f.h"
#include "../SR/STACK_SR_Specif.h"


/*------------------
Private declarations
------------------*/

typedef struct p_node_t {  // node of a 'simple linked' predecessor list
  elt_t e;                 // element to be stored in a node
  struct p_node_t *pred;   // points to the predecessor node
} p_node_t;

typedef struct stack_descr_t {
  p_node_t *top;     // points to the top node, i.e. last in element
  long size;         // number of elements in the STACK
} stack_descr_t;

/*--- sketch of the data structure ------------
   
         /---|*| <---|*| <---|*|
                 pred         |
                             top
---------------------------------------------*/

stack_descr_t *s = NULL;  // shared variable                            //---YYY


/*----------
Constructors
----------*/


void stack_create(long cap)
//------------------------- 'cap' is not used for UL implementation
{
  //--- possibly find a free place and update descriptor
  s = malloc(sizeof *s);                  // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)

  s->top = NULL;
  s->size = 0;
}


void stack_destroy()
//------------------
{
  p_node_t *tmp = s->top;
  
  while (tmp != NULL) 
  {s->top = tmp->pred; free(tmp); tmp = s->top;}          // free STACK instance

  free(s);                                              // free STACK descriptor
  s = NULL;                                            // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(elt_t *e)
//----------------------
{
  //--- possibly find a new place
  p_node_t *buf = malloc(sizeof *buf);           // memory allocation: next node
                               // (is deallocated by stack_destroy or stack_get)

  //--- copy *e and update descriptor
  buf->e = *e;
  buf->pred = s->top;
  
  s->top = buf;
  ++s->size; 
}


void stack_get(elt_t *e)
//----------------------
{
  p_node_t *tmp = s->top;

  //--- verify precondition
  if (tmp == NULL) exit(EXIT_FAILURE); // stack is empty
  
  //--- update *e and descriptor
  *e = tmp->e;

  s->top = tmp->pred;
  --s->size;

  //--- free space
  free(tmp);                                            // free the old top node
}


/*--------------
Access functions
--------------*/


void stack_consult(elt_t *e)
//--------------------------
{
  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty
  
  //--- update *e
  *e = s->top->e;
}


boolean_t stack_is_empty()
//------------------------
{
  return s->top == NULL;
}


boolean_t stack_is_full()
//-----------------------
{
  return FALSE;
}


boolean_t stack_is_mem_av()
//-------------------------
{
  return TRUE;
}


/*---------------
Traverse function
---------------*/


void stack_traverse(void fct(buf_t *), buf_t *buf)
//------------------------------------------------
{
  p_node_t *tmp = s->top;
  
  while (tmp != NULL) {
    buf->elt1 = &tmp->e;
    fct(buf);
    tmp = tmp->pred;
  }
}
