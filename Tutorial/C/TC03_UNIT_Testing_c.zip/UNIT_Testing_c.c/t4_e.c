/*--------------------------------------------------------------------------------
Title: Simple test program for two concurrent primitives, with error treatment
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland
Version: version 1, 9 September 2007

Description: This test program gives an ad hoc implementation of an elementary
stack, in order to illustrate how to test it.

Comments: 
Not that the error treatment is fully localized at the end of the main loop, and 
is so properly separated from the rest of the test program. 

A error treatment variant using a global error_number will be presented in the 
test programs for abstract data types (ADT)
--------------------------------------------------------------------------------*/

/* ---------------------------------------------------- */
/* add, remove and consult "module" ------------------- */
/* ---------------------------------------------------- */

#define ALLOCSIZE 5 /* size of the storage space */

static char allocbuf[ALLOCSIZE];   /* storage */
static int top=0;	   /* next free position */

int push(int n)   /* add n to allocbuf in LIFO order*/
{
    if (top < ALLOCSIZE) { /* it fits in */ 
        allocbuf[top++] = n;
        return 1;
    } else  /* not enough memory */
        return 0;
}

int pop(void)   /* remove item in LIFO order */
{
    if (top > 0) { /* there is an item, remove it */ 
        top--;
        return 1;
    } else  /* allocbuf is empty */
        return 0;
}

int consult(int *n)   /* consult last added item */
{
    if (top > 0) { /* there is an item */ 
        *n = allocbuf[top-1];
        return 1;
    } else  /* allocbuf is empty */
        return 0;
}


/* ----------------------------------- */
/* Main test program ----------------- */
/* ----------------------------------- */

#include <stdio.h>

void print_usage()
//----------------
{
  printf("Usage:              p)push(i) o)pop  c)consult\n");
  printf("Test program usage: M)Maximal_size\n");
  printf("                    H)Help    Q)Quit M)Maximal_size\n");
}

int main() /* Test program for the push/pop/consult functions */
{
  char c; 
  int n;
  
  char *prompt = ">";
  
  print_usage();
  printf("%s", prompt);

  /*---------------------------
  Main loop of the test program
  ---------------------------*/
  while ((c = getchar())) {
    switch(c) {
      
      case 'p':
		if (!scanf("%i", &n)) goto error10;  // read input
		if (!push(n)) goto error1;  // add to storage
		printf("added item: %d\n",n);
        break;
      
      case 'o':
		if (!pop()) goto error2;  // remove from storage 
        printf("last added item has been removed\n");
        break;
      
	  case 'c':
        if (!consult(&n)) goto error3;
		printf("last added item: %i\n", n);
        break;
      
	  case 'M':
        printf("Maximal stack size: %d\n", ALLOCSIZE);
        break;
      
	  case 'H':
        print_usage();
        break;
        
      case 'Q': 
        return 0;
 
      default:
        print_usage();
        break;
    }
    while (getchar() != '\n') {} /* skip end of line */
    printf("%s", prompt);
	continue;  // all is ok, go to the beginning of the main loop
	
	/*----- ERROR TREATMENT -----*/ 
error1:
    while (getchar() != '\n') {} /* skip end of line */
    printf("test program> ERROR: Stack is full; no item have been added\n");
    printf("%s", prompt);
	continue; // retry, go to the beginning of the main loop
error2:
    while (getchar() != '\n') {} /* skip end of line */
    printf("test program> ERROR: Stack is empty; no item have been poped \n");
    printf("%s", prompt);
	continue; // retry, go to the beginning of the main loop
error3:
    while (getchar() != '\n') {} /* skip end of line */
    printf("test program> ERROR: Stack is empty; no item can be consulted\n");
    printf("%s", prompt);
	continue; // retry, go to the beginning of the main loop
error10:
    while (getchar() != '\n') {} /* skip end of line */
    printf("test program> ERROR: Input format error\n");
    printf("%s", prompt);
	continue; // retry, go to the beginning of the main loop
  }
  /*--------------------------------------
  End of the main loop of the test program
  --------------------------------------*/
}