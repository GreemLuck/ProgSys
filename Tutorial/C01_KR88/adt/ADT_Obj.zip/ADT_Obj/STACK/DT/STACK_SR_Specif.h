/*-------------------------------------------------------------------------------
STACK subroutines specification
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: DT v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#define STACK_SR_SPECIF_VERSION "STACK SR specification version : DT v4.1, 10 March 2013"

/*----------
Constructors
----------*/
void stack_create (stackt *s, long cap); // 'cap' is not used for UL implementations
void stack_destroy(stackt *s);

/*----------
Manipulators
----------*/
void stack_put(stackt *s, elt_t *e);
void stack_get(stackt *s, elt_t *e);

void stack_new_capacity(stackt *s, long nc);  // do nothing for UL implementations

/*--------------
Access functions
--------------*/
void       stack_consult    (stackt s, elt_t *e);
boolean_t  stack_is_empty   (stackt s);
boolean_t  stack_is_full    (stackt s);
boolean_t  stack_is_mem_av  (stackt s);

boolean_t  stack_exists     (stackt s);
long       stack_size       (stackt s);
long       stack_capacity   (stackt s); // returns -1 for UL implementations

char*      stack_impl_version();
char*      stack_impl_type();

/*---------------
Traverse function
---------------*/
void stack_traverse(stackt s, void fct(buf_t *), buf_t *buf);