/*--------------------------------------------------------------------------------
Title: System call wait in combination with fork and exec
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 07, Dec. 11
Reference: Brian W. Kernighan, Rob Pike: "The Unix Programming Environment",
           Prentice-Hall, 1984, chap. 7.4 Processes (pp. 220-225)

DESCRITION
Similar to few1, but with a more flexible input.

USAGE
% few2 prog_name [options_or_other_arguments]
   (where 'prog_name' is the name of a program in the search path $PATH or 
   'prog_name' contains the full pathname)
   
EXERCISES
Explain and verify on machine the behavior of:
1. % few2 pwd
2. % few2 ls -a -l
3. % few2 pwd > result.txt  // Only for advanced students:
                            // Try to explain the rather surprising behavior!!!
--------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void print_usage() {
  printf("usage: few2 prog_name [options_or_other_arguments]\n");
}

void print_command(char *p[])
{
  int i;
  for (i=0; p[i] != NULL; i++)
    printf("%s ", p[i]);
}


int main(int argc, char *argv[]) 
{
  char *argp[10];
  int i, pid, status;
  
  if (argc < 2) {print_usage(); return -1;}
  
  // 'argp' initialization
  for (i=0; argv[i] != NULL; i++)
    argp[i] = argv[i+1];
  argp[i] = NULL;

  pid = fork();
  if (pid==-1) { // Error, the fork call didn't worked
    printf("> Error: the fork call didn't worked\n");
    return -1;
  } 
  else if (pid==0) { // Child process
    printf("\n> Hello, I'm the child process\n");
    printf("> My pid is %i and my parent pid is %i\n", getpid(), getppid());
    printf("> and will launch the ' ");
    print_command(argp);
    printf("' command\n");
    execvp(argp[0],argp);  // program overlay !
  } 
  else { // Parent process
    printf("\n> Hello, I'm the parent process. The pid of my child is: %i\n", pid);
    printf("> My pid is %i and my parent pid is %i\n", getpid(), getppid());
    wait(&status);
    printf("\n> My child %i terminated with status = %i\n", pid, status);
  }
  return 0;
}
