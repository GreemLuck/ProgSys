#include <stdio.h>

void printsys(void){
	printf("vista system\n");
}
