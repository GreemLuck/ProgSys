/*--------------------------------------------------------------------------------
Title: Program overlay - execl and execlp
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 2006
Reference: Brian W. Kernighan, Rob Pike: "The Unix Programming Environment",
           Prentice-Hall, 1984, chap. 7.4 Processes (pp. 220-225).
		   See also the Unix man page execl and execve.

DESCRIPTION

  execl(filename_with_path, arg0, arg1, ..., argn, NULL)
  execlp(filename, arg0, arg1, ..., argn, NULL)

The first argument to execl is the filename of the command, with the pathname.
The second and subsequent arguments are the command name and the arguments of the 
command; these become the argv array of the new program. The end of the list is
marked by 0 argument.

The execl call overlays the existing program with the new one, runs that, then
exits. The original program gets control back only when there is an error, for
example if the file can't be found or is not executable.

Remark. execlp is a variant of execl, where the first argument is also the 
filename but without the explicit path. The primitive execlp extracts the search 
path (i.e., $PATH) from the environment and does the same search as the shell does.

Remark 2. Other exec variants exist: execle, execv, execve, excvp, execvP.

USAGE
% exec1
--------------------------------------------------------------------------------*/

#include <unistd.h> // execl(), execlp()
#include <stdio.h>

int main() 
{
  printf("> Before the execl call\n");
  execl("/bin/date", "date", NULL);  // execlp("date", "date", NULL)
  printf("> Couldn't execute 'date'\n");
  return 0;
}
