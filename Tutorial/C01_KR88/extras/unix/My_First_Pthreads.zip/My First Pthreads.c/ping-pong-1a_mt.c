/*-----------------------------------------------------------------------------
Short description: My first thread program: ping-pong,

Short description: My first thread program: ping-pong.

Description: One thread displays N times ping and the other PONG. The program 
illustrates how to:

   - define and use a shared variable
   - create two threads
   - wait on the exit of the two created threads 
   
Usage: progr_name <N>

Example: progr_name 1000

Author: Beat Hirsbrunner
Version: 1.0, 31 December 2008 / rev. 15 March 2009, 5 Dec. 2010
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>  // atoi
#include <pthread.h>

/*-------------------------------*/
/*-----   Shared variable   -----*/
/*-------------------------------*/
int N;

/*-------------------------------*/
/*-----   Thread function   -----*/
/*-------------------------------*/
void *display(void *arg) 
{
   int n=0;
    
   /*-----   main loop   -----*/ 
   while(n++< N) {
      printf("%s ", (char *)arg);  // casting of void pointer
      sched_yield();               // yield the processor to another thread
   }

   printf("\nBye bye from %s thread\n", (char *)arg);
  
   pthread_exit(NULL);             // not mandatory, but signals a proper exit
}

/*-----------------------------*/
/*-----   main function   -----*/
/*-----------------------------*/
int main(int argc, char *argv[]) 
{
   pthread_t thread0, thread1;
   char      *message0 = "ping", *message1 = "PONG";

   if (argc != 2) {
	   fprintf(stderr, "-----Usage: %s <N>\n", argv[0]);
	   exit(-1);
	}
   
   /*-----   Initialization   -----*/
   N = atoi(argv[1]);
    
   /*-----   Create two threads   -----*/
   pthread_create(&thread0, NULL, display, message0);
   pthread_create(&thread1, NULL, display, message1);
  
   /*-----   Wait the exit of the two created threads   -----*/
   pthread_join(thread0, NULL); // wait on thread0 exit
   pthread_join(thread1, NULL); // wait on thread1 exit
  
   /*-----   Termination   -----*/
   printf("Bye bye from main thread\n");
   return 0;
}