/*--------------------------------------------------------------------------------
STACK test program
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: SR v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdio.h>     // printf, scanf
#include <stdlib.h>    // malloc, free
#include <string.h>    // strcpy, strlen
#include <unistd.h>    // isatty 

#include "../MTE/type_f.h"                                              //---YYY
#include "../SR/STACK_SR_Specif.h"                                      //---YYY

#define STACK_TEST_VERSION "STACK test program version: SR v4.1, 10 March 2013"

typedef struct res_size_t // used by size()
{
  long nb_elt;    // number of elements 'elt' stored in the STACK
  long size_elt;  // size in bytes of all elt
  long size_key;  // size in bytes of all elt->key
  long size_data; // size in bytes of all elt->data
  long size_str;  // size in bytes of the strings stored by all elt->data
} res_size_t;

void display(buf_t *buf)  // user supplied function for traverse
//--------------------------------------------------------------
{
  //--- prints all elements of the STACK
  printf("%li %s\n", buf->elt1->key, buf->elt1->data);
} 

void occurrence(buf_t *buf)  // user supplied function for traverse
//-----------------------------------------------------------------
{ 
  //--- counts the occurences of user supplied 'buf->elt2->key'
  if (buf->elt1->key == buf->elt2->key) ++*(long *)buf->res; 
} 

void size(buf_t *buf)  // user supplied function for traverse
//-----------------------------------------------------------
{ 
  //--- counts miscellaneous sizes of the STACK 
  res_size_t *tmp = buf->res; //local variable tmp just to avoid annoying castings
  ++tmp->nb_elt;
  tmp->size_elt  += sizeof(*buf->elt1);
  tmp->size_key  += sizeof(buf->elt1->key);
  tmp->size_data += sizeof(buf->elt1->data);
  tmp->size_str  += strlen(buf->elt1->data);
} 

void print_usage()
//----------------
{
  printf("Stack object usage\n");
  printf("------------------\n");
  printf("Constructors :  c)create(i)     d)destroy\n");
  printf("Manipulators :  p)put(i,s)      g)get\n");
  printf("Access fcts  :  o)consult\n");
  printf("                e)is_empty      f)is_full         m)is_mem_av\n");
  printf("Traverse fcts:  td)display      to)occurrence(i)  ts)size\n");
  printf("\n");
  printf("Test program :  H)Help           Q)Quit\n");
  printf("Virtual Mem. :  O)Fill_Obj(i)\n");  
}

int main(int argc, char *argv[]) 
//------------------------------
{
  // STACK variables
  //----------------
  long capacity = 2;      // default stack 'capacity'
  stack_create(capacity); // default stack

  #if __fixed_data_length__  //--- defined in "../MTE/type_f.h" and "../MTE/type_m.h"
    elt_t elt = {1, "Hello"};
  #elif __mutable_data_length__
    elt_t elt = {1, malloc(MTE_MAX_STR_LEN + 1)};
    strcpy(elt.data, "Hello");
  #endif

  buf_t buf = {NULL, NULL, NULL};  // buffer used by traverse
  
  // Test program variables
  //-----------------------
  char c;  // 'switch(c)' of the main loop
  
  // t, X, Y, Z, O, M commands
  long li;                  // counter
  long grain = 1000L*1000L; // grain to display only every 'grain' occurrences
  
  long t;                   // amount of counting

  // display management
  //-------------------  
  const char *prompt = "> ";
  int prompt_count = 1;
  
  if (isatty(0) && isatty(1)) // 'isatty' is read 'is a tty', i.e. a terminal, with
  {                           // 0 for standard input stream, e.g. keyboard
                              // 1 for standard output stream, e.g. display
    print_usage();
    printf("\nBEWARE, use the virtual memory functionality O with great");
    printf(" care as it may severely crash your machine !!!\n\n");
  }                                
  printf("%i%s", prompt_count++, prompt);
  
  
  /*---------------------------
  Main loop of the test program
  ---------------------------*/
  while ( (c = getchar()) != 'Q')
  {
    switch(c)
    {
      /*----------
      Constructors
      ----------*/      
      case 'c':  // create
        if (scanf("%li", &capacity) != 1) goto error_scanf;//--- ERROR TREATMENT
        
        stack_create(capacity);
        
        printf("STACK has been created\n");
        break;
        
      case 'd':  // destroy
        stack_destroy();
        printf("STACK has been destroyed\n");
        break;
        
      /*----------
      Manipulators
      ----------*/
      case 'p':  // put
        if (scanf("%li%s", &elt.key, elt.data) != 2) goto error_scanf;
                                                           //--- ERROR TREATMENT        
        stack_put(&elt);

        printf("%li %s\n", elt.key, elt.data);
        break;
        
      case 'g':  // get
        stack_get(&elt);
        printf("%li %s\n", elt.key, elt.data);
        break;
        
      /*---------
      Access fcts
      ---------*/     
      case 'o':  // consult
        stack_consult(&elt);
        printf("%li %s\n", elt.key, elt.data);
        break;
        
      case 'e':  // is_empty
        if (stack_is_empty())
          printf("yes\n");
        else
          printf("no\n");
        break;
        
      case 'f':  // is_full
        if (stack_is_full()) 
          printf("yes\n");
        else
          printf("no\n");
        break;
        
       case 'm':  // is_mem_av
        if (stack_is_mem_av()) 
          printf("yes\n");
        else
          printf("no\n");
        break;
	       
      /*------------
      STACK traverse
      ------------*/
      case 't':
      { 
        switch (getchar())  //--- subcases of traverse 't'
        {
          case 'd':  // traverse with display
            stack_traverse(display, &buf);
            printf("--- /t display\n");
            break;
		          
          case 'o':  // traverse with occurence
          {
            long res = 0;

            buf.elt2 = &elt; // occurence compares buf.elt2->key with buf.elt1->key
            if (scanf("%li", &buf.elt2->key) != 1) 
              goto error_scanf;                            //--- ERROR TREATMENT
            buf.res = &res;  // *buf.res is updated by occurence
            
            stack_traverse(occurrence, &buf);
            
            printf("%li\n", res);
            printf("--- /t occurrence\n");
            break;
          }
		        
          case 's':  // traverse with size
          {
            res_size_t res = {0, 0, 0, 0, 0};
            buf.res = &res;  // *buf.res is updated by size

            stack_traverse(size, &buf);
            
            printf("%li elts, %li B/elt (%li B/elt.key, %li B/elt.data), %li B strings\n", 
                   res.nb_elt, 
                   res.nb_elt ? res.size_elt/res.nb_elt : sizeof(elt), 
                   res.nb_elt ? res.size_key/res.nb_elt : sizeof(elt.key), 
                   res.nb_elt ? res.size_data/res.nb_elt : sizeof(elt.data), 
                   res.size_str);
            printf("--- /t size\n");
            break;
          }
            
          default:
            if (isatty(0) && isatty(1)) print_usage(); else printf("---\n");
            break;
        } // end subcases            
        break;
      } //--- end case 't'
             
      /*-------------------------
      Test Program: miscellaneous
      -------------------------*/
      case 'H':
        if (isatty(0) && isatty(1)) print_usage(); else printf("---\n");
        break;
        
      /*-------------------------------------------------------------------                         
      Memory usage: Virtual memory observation: allocate memory as long as time 
      is not over (with time measured in ticks)
      
      Beware, use this command with great care as it may severely crash your
      machine (only Fill_Obj for bounded objects is harmless)
      
      Observe VM behaviour with a tool like 'vmstat' or 'Activity Monitor'
      -------------------------------------------------------------------*/                           
      case 'O':  // fill up current stack object: 'put' loop
        li = 0;     
        elt.key = 0;
        strcpy(elt.data,"Fill up the current obj, with strlen(elt.data): 50");
        
        if (scanf("%li", &t) != 1) goto error_scanf;       //--- ERROR TREATMENT

        while (t-- > 0 &&
                stack_is_mem_av() &&
               !stack_is_full() )
        {
          ++elt.key;
          stack_put(&elt);
          
          if ( !(++li % grain) ) printf("%li\n", li/grain);
        }
        
        printf("%li\n", li);
        printf("--- /O\n");
        break;
        
      default:
        if (isatty(0) && isatty(1)) print_usage(); else printf("---\n");
        break;
    }
    while (getchar() != '\n') {} /* skip end of line */
    printf("%i%s", prompt_count++, prompt);
    continue;  // all is ok, go to the beginning of the main loop
    
/*----- ERROR TREATMENT -----*/ 
error_scanf:
    while (getchar() != '\n') {} /* skip end of line */
    printf("%s: ERROR: wrong scanf argument\n", argv[0]);
    printf("%i%s", prompt_count++, prompt);
    continue;
/*----- END ERROR TREATMENT -----*/     
  }
  /*--------------------------------------
  End of the main loop of the test program
  --------------------------------------*/
  #if __mutable_data_length__
    free(elt.data);
  #endif
  printf("Quit\n");
  return 0;
}