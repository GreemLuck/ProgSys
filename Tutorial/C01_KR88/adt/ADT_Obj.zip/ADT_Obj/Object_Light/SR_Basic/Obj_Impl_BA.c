/*--------------------------------------------------------------------------------
ADT object subroutines implementation (for object = STACK and FIFO)
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: BA v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>                                   // exit
#include "Obj_SR_Specif.h"                            // obj_t, put, get
#include "../../STACK_Light/Basic/STACK_SR_Specif.h"  // stack_put, stack_get
#include "../../FIFO_Light/Basic/FIFO_SR_Specif.h"    // fifo_put, fifo_get


void put(obj_t obj, int e)
{
  switch (obj)
  {
    case STACK: stack_put(e); break;
    case FIFO : fifo_put(e); break;
    default: exit(EXIT_FAILURE); // unknown object type
  }
}


int get(obj_t obj)
{
  switch (obj)
  {
    case STACK: return stack_get(); break;
    case FIFO : return fifo_get(); break;
    default: exit(EXIT_FAILURE); // unknown object type
  }
}
