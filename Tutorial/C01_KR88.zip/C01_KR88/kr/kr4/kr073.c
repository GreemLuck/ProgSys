/* atoi: convert string s to integer using atof --- kr73 */
int atoi(char s[])
{
    double atof(char s[]);

    return (int) atof(s);
}
