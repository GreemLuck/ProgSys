/*--------------------------------------------------------------------------------
Title: Simple test program with error treatment
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland
Version: version 1, 9 September 2007

Description: Read from the standard input a list of keys (integer) until EOF is 
encountered, do some action on the readed data (i.e. do nothing!), and print
the result, one key per line. Some lines may contain misformatted data; in this 
case the rest of the line is skipped.
--------------------------------------------------------------------------------*/

#include <stdio.h>

int main() {
  int i, max=0, key[1000];
  int d; char c;  //--- for error treatment; d for diagnostic

  // Read the data (with error treatment) ------------------------------
  while ((d=scanf("%d", &key[max++])) != EOF) { 
    if (d == 0) { //--- error treatment
      while ((c=getchar()) != '\n') 
      	; // skip the rest of the input line
	  --max; // max has been incremented once to much
	 } 
  } // end of readings
  // -------------------------------------------------------------------
  --max; // max has also been incremented when scanf has encountered EOF !
  
  // Do some action (here do nothing!)
 
  // Print the result
  printf("-----\n");
  for (i=0; i<max; ++i) printf("%d\n", key[i]);
}