/*--------------------------------------------------------------------------------
Title: exec variants - execl, execlp, execle and execv, excevp, execvP
Author: B. Hirsbrunner, University of Fribourg, June 2006
Reference: Ch. Dannegger, P. Geugelin-Dannegger: "Parallele Prozesse unter 
           UNIX", Carl Hanser Verlag Muenchen Wien, 1991. See also the man pages 
		   for execl and execve.

PROTOTYPES
int execl (filename_with_path, arg0, arg1, ..., argn, NULL)
int execle(filename_with_path, arg0, arg1, ..., argn, NULL, envp)
int execlp(filename,           arg0, arg1, ..., argn, NULL)

int execv (filename_with_path, argp)
int execve(filename_with_path, argp, envp)
int execvp(filename, argp)
int execvP(filename, search_path, argp)

char *filename_with_path, *filename, *search_path;
char *arg0, *arg1, ..., *argn;
char *argp[], *envp[]  // these arrays of pointers must be terminated by NULL

USAGE
program_name [-1234567]
--------------------------------------------------------------------------------*/
#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) 
{
  char *argp[2] = {"date", NULL};
  char *envp[1] = {NULL};
  
  if (argc!=2) {
    printf("> Usage: program_name [-1234567]\n");
    return -1;
  }
  
  switch (argv[1][1]) {
    case '1': 
      printf("> Before the execl call\n");
      execl("/bin/date", "date", NULL);
      break;  
    case '2': 
      printf("> Before the execle call\n");
      execle("/bin/date", "date", NULL, NULL);
      break;      
    case '3':
      printf("> Before the execlp call\n");
      execlp("date", "date",  NULL);  // file 'date' is in the search path $PATH
      break;
    case '4':
      printf("> Before the execv call\n");
      execv("/bin/date", argp);
      break;
    case '5':
      printf("> Before the execve call\n");
      execve("/bin/date", argp, envp);
      break;
    case '6':
      printf("> Before the execvp call\n");
      execvp("date", argp);  // file 'date' is in the search path $PATH
      break;
    case '7':
      printf("> Before the execvP call\n");
      execvP("date", "/bin", argp);  // file 'date' is in the directory /bin
      break;
    default:
      printf("> Usage: program_name [-1234567]\n");
      return -1;
      break;
  }
  
  printf("> After the execXY call\n");
  return 0;
}
