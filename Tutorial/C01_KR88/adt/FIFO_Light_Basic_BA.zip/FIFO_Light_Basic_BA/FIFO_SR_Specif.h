/*-------------------------------------------------------------------------------
FIFO subroutines specification
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: Basic v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

void fifo_put(int e);
int fifo_get();