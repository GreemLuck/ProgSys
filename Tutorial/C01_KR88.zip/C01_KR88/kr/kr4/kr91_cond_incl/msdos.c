#include <stdio.h>

void printsys(void){
	printf("msdos system\n");
}
