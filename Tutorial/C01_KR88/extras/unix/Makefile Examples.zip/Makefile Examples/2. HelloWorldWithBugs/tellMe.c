#include <stdio.h>
#include "tellMe.h"

void tellMe(char s[])
{
   printf("\n   tellMe> %s\r\n\n", s);
}
