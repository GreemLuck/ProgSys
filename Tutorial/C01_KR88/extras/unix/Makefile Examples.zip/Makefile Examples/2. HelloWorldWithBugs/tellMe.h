void tellMe(char s[]);
