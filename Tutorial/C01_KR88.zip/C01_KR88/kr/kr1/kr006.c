#include <stdio.h>
main() /* --- kr6 */
{
   printf("hello, world\n");
}
