/*--------------------------------------------------------------------------------
Title: Program overlay - a variant
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 2006

DESCRIPTION
A variant of the program 'exec1.c': the program to overlay can be choosen by
launching 'exec2'. Restriction: only the first option of the program to be launched
is taken into account. This restriction is relaxed in version 3.

USAGE
% exec2 prog_name [option]  
   (where 'prog_name' is the name of a program in the search path $PATH or 
   'prog_name' contains the full pathname)
   
EXERCISE
What happens with the following commands? Verify on machine and explain your 
observations. If necessary, draw the 'Process Model Diagram' and pay attention 
to the arguments passed to the program.

1.  % exec2 date
2.  % exec2 ls -a
3.  % exec2 ls -al
4.  % exec2 ls -a -l  // Why is the '-l' option not taken into account ?
5.  % exec2 exec2 // exec2 is overlaid exactly once with exec2. Explain
6.  % exec2 exec2 date // exec2 is overlaid with exec2 and then with date. Explain.
--------------------------------------------------------------------------------*/

#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) 
{
  if (argc < 2) {
    printf("usage: exec2 prog_name [<option>]\n");
	return -1;
  }
  
  printf("> Before the call of the program '%s' with 'execlp'\n", argv[1]);
  
  if (argc==2)  
    execlp(argv[1], argv[1], NULL);
  else 
    execlp(argv[1], argv[1], argv[2], NULL);
  
  printf("> Couldn't execute '%s'\n", argv[1]);
  return 0;
}
