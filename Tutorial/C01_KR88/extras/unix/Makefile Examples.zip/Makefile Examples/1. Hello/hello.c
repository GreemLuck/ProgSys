void tellMe(void);
main () {tellMe();}
