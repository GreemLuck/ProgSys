The makefile examples of this repertory are commented in the tutorial 
"Make: 1st Contact", available at "diuf.unifr.ch/pai/ip/tutorials".