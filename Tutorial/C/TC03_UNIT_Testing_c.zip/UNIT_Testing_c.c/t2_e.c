/*--------------------------------------------------------------------------------
Title: Simple test program with error treatment
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland
Version: version 1, 9 September 2007

Description: Read from the standard input a list of keys (integer) and words, and 
print them, until EOF is encountered. Some lines may contain misformatted data; 
in this case the rest of the line is skipped.

Usage: t2_e 
       t2_e < t2_e.txt

Comment: Note that the error treatment is done at the end of the main loop while,
and is so properly separated from the rest of the algorithm!
--------------------------------------------------------------------------------*/

#include <stdio.h>

int main() {
  int key;
  char word[20];
  int d; char c;  // for error treatment; d for diagnostic

  // --------------------------------------------------------------------
  while ((d = scanf("%d %s", &key, word)) != EOF) { // Read the next data
    if (d >= 0 && d < 2) goto error
    	;  //--- error treatment

    // Do some action (here nothing is done)
	
    printf("%d %s\n", key, word); // Print the result
	continue; // read the next data

error: //--- error treatment
    while ((c=getchar()) != '\n') ; // skip the rest of the input line
	printf("Number returned by scanf: %d. Try again.\n", d);
  } // end of readings
  // --------------------------------------------------------------------
}