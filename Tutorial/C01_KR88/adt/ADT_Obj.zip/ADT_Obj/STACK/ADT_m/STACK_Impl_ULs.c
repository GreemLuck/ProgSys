/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: ULs_mut v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // malloc, realloc, free
#include <string.h>  // strcpy, strlen                                  //---YYY
#include "../MTE/error.h"
#include "../MTE/type_m.h"                                              //---YYY
#include "../ADT/STACK_DT_Specif.h"
#include "../ADT/STACK_SR_Specif.h"

#define STACK_SR_IMPL_VERSION "STACK SR implementation version: ULs_mut v4.1, 10 March 2013"


/*------------------
Private declarations
------------------*/

typedef struct p_node_t {  // node of a 'simple linked' predecessor list
  elt_t e;                 // element to be stored in a node
  struct p_node_t *pred;   // points to the predecessor node
} p_node_t;

typedef struct stack_descr_t {
  p_node_t *top;     // points to the top node, i.e. last in element
  long size;         // number of elements in the STACK
  boolean_t mem_av;  // false if no more node can be added to the STACK and true otherwise
  p_node_t *buf;     // buffer for a new node
} stack_descr_t;

/*--- sketch of the data structure -------------------------------      //---YYY    
        ---------      ---------------------          ----------------------
        | * | \0|      | * | * | * | * | \0|          | a big empty buffer |
        ---------      ---------------------          ----------------------
          |              |                              |
          |              |                              |
/-----| * | |  <-----| * | |                  /-----| * | |
                pred   |                              |
                      top                            buf
------------------------------------------------------------------------------*/


/*----------
Constructors
----------*/


void stack_create(stackt *_s, long cap)
//------------------------------------- 'cap' is not used for UL implementation
{
  //--- possibly find a free place and update descriptor
  stack_descr_t *s = malloc(sizeof *s);   // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)

  if (s == NULL)                                           //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory;
    return;
  }

  p_node_t *b = malloc(sizeof *b);            // memory allocation: STACK buffer
                                            // (is deallocated by stack_destroy)

  if (b == NULL)                                           //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory;
    free(s);
    return;
  }
  
  b->e.data = malloc(MTE_MAX_STR_LEN + 1);  // memory allocation: data  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY

  if (b->e.data == NULL)                         //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    MTE_error = MTE_ERROR_out_of_memory;                                //---YYY
    free(b);                                                            //---YYY
    free(s);                                                            //---YYY
    return;                                                        //---YYY
  }                                                                     //---YYY

  s->top = NULL;
  s->size = 0;
  s->mem_av = TRUE;
  s->buf = b;
  *_s = s;
}


void stack_destroy(stackt *_s)
//----------------------------
{
  stack_descr_t *s = *_s;
  p_node_t *tmp = s->top;
  
  while (tmp != NULL)                                       // free ADT instance
  {
    s->top = tmp->pred;
    free(tmp->e.data);                                                  //---YYY
    free(tmp);
    tmp = s->top;
  }

  if (s->buf != NULL && s->buf->e.data != NULL) free(s->buf->e.data);   //---YYY
  if (s->buf != NULL) free(s->buf);                               // free buffer
  free(s);                                              // free STACK descriptor
  *_s = NULL;                                          // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (!s->mem_av)                                          //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR_out_of_memory; 
    return; 
  }

  if (strlen(e->data) > MTE_MAX_STR_LEN)         //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    MTE_error = MTE_ERROR_data_string_length_is_too_long;               //---YYY
    return;                                                             //---YYY
  }                                                                     //---YYY

  //--- copy *e and update descriptor
  s->buf->e.key = e->key;                                               //---YYY
  strcpy(s->buf->e.data, e->data);                                      //---YYY
  s->buf->e.data = realloc(s->buf->e.data, strlen(e->data) + 1);        //---YYY
                // assuming that reducing string length always succeed  //---YYY                 
  s->buf->pred = s->top;
  
  s->top = s->buf;
  ++s->size; 
  
  //--- possibly reserve a free place
  s->buf = malloc(sizeof *s->buf);            // memory allocation: STACK buffer
                               // (is deallocated by stack_destroy or stack_get)
  
  if (s->buf == NULL)                                      //--- ERROR TREATMENT
  {
    s->mem_av = FALSE;                          // used by 'put' and 'is_mem_av'
    //--- error treatment will be made by a coming 'put' call
    return;                                                             //---YYY
  }
  
  s->buf->e.data = malloc(MTE_MAX_STR_LEN + 1);                         //---YYY
                                            // memory allocation: data  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY
  
  if (s->buf->e.data == NULL )                   //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    free(s->buf);                                                       //---YYY
    s->mem_av = FALSE;                // used by 'put' and 'is_mem_av'  //---YYY
    //--- error treatment will be made by a coming 'put' call           //---YYY
  }                                                                     //---YYY
}


void stack_get(stackt _s,  elt_t *e)
//----------------------------------
{
  stack_descr_t *s = _s;
  p_node_t *tmp = s->top;

  //--- verify precondition
  if (tmp == NULL)                                         //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__object_is_empty;
    return;
  }
  
  //--- update *e and descriptor
  e->key = s->top->e.key;                                               //---YYY
  strcpy(e->data, s->top->e.data);                                      //---YYY

  s->top = tmp->pred;
  --s->size;

  //--- free space and possibly reserve a free place
  if (s->mem_av) 
  {  
    free(tmp->e.data);                                                  //---YYY
    free(tmp);                                          // free the old top node
    return;                                                             //---YYY
  }

  // at this point 'mem_av' is false
  s->buf = tmp;                            // give this place back to the buffer

  s->buf->e.data = realloc(s->buf->e.data, MTE_MAX_STR_LEN + 1);        //---YYY
                                          // memory reallocation: data  //---YYY
                     // (is deallocated by stack_destroy or stack_get)  //---YYY
                                                                        //---YYY
  if (s->buf->e.data != NULL ) s->mem_av = TRUE;                        //---YYY
  else                                           //--- ERROR TREATMENT  //---YYY
  {                                                                     //---YYY
    free(s->buf);                                                       //---YYY
    //--- error treatment will be made by a coming 'put' call           //---YYY
  }                                                                     //---YYY
}


void stack_new_capacity(stackt _s, long nc)
//-----------------------------------------
{
  // do nothing, capacity is not used for UL implementations
}


/*--------------
Access functions
--------------*/


void stack_consult(stackt _s,  elt_t *e)
//--------------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0)                                        //--- ERROR TREATMENT
  {
    MTE_error = MTE_ERROR__object_is_empty;
    return;
  }
  
  //--- update *e
  e->key = s->top->e.key;                                               //---YYY
  strcpy(e->data, s->top->e.data);                                      //---YYY
}


boolean_t stack_is_empty(stackt _s)
//--------------------------------
{
  stack_descr_t *s = _s;
  return s->top == NULL;
}


boolean_t stack_is_full(stackt _s)
//-------------------------------
{
  return FALSE;
}


boolean_t stack_is_mem_av(stackt _s)
//----------------------------------
{
  stack_descr_t *s = _s;
  return s->mem_av;
}


//----- other access functions   -----


boolean_t stack_exists(stackt _s)
//-------------------------------
{
  return _s != NULL;
}


long stack_size(stackt _s)
//------------------------
{
  stack_descr_t *s = _s;
  return s->size;
}


long stack_capacity(stackt _s)
//----------------------------
{
  return CAP_UL;
}


char *stack_impl_version() 
//------------------------
{
  return STACK_SR_IMPL_VERSION;
}


char *stack_impl_type() 
//---------------------
{
  return "ULs_mut";                                                     //---YYY
}


/*---------------
Traverse function
---------------*/


void stack_traverse(stackt _s, void fct(buf_t *), buf_t *buf)
//-----------------------------------------------------------
{
  stack_descr_t *s = _s;
  p_node_t *tmp = s->top;
  
  while (tmp != NULL) {
    buf->elt1 = &tmp->e;
    fct(buf);
    tmp = tmp->pred;
  }
}
