/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: BAs v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // exit, malloc, realloc, free
#include "../MTE/type_f.h"
#include "../SR/STACK_SR_Specif.h"


/*------------------
Private declarations
------------------*/

typedef struct stack_descr_t {
  elt_t *base;    // points to the base elt of the STACK array instance
  long top;       // pseudo pointer referring to the next free entry
  long size;      // 0 <= size <= capacity
  long capacity;  // capacity of the STACK instance, >= 0
} stack_descr_t;

/*--- sketch of the data structure ---------
           -----------------------------
           | * | * | * | * |   |   |   | 
           ----------------------------- 
             |              top
            base
------------------------------------------*/

stack_descr_t *s = NULL;  // shared variable                            //---YYY


/*----------
Constructors
----------*/


void stack_create(long capacity)
//------------------------------
{
  //--- verify precondition
  if (capacity < 0) exit(EXIT_FAILURE); // negative capacity is not allowed

  //--- possibly find a free place and update descriptor
  s = malloc(sizeof *s);                  // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)
  
  s->base = malloc(capacity * sizeof(elt_t)); // memory allocation: STACK instance
                                              // (is deallocated by stack_destroy)

  s->top = 0;
  s->size = 0;
  s->capacity = capacity;
}


void stack_destroy()
//------------------
{
  free(s->base);                                          // free STACK instance
  free(s);                                              // free STACK descriptor
  s = NULL;                                            // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(elt_t *e)
//----------------------
{
  //--- verify precondition
  if (s->size == s->capacity) exit(EXIT_FAILURE); // stack is full
  
  //--- copy *e and update descriptor
  s->base[s->top] = *e;
  ++s->top;
  ++s->size;
}


void stack_get(elt_t *e)
//----------------------
{
  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e and descriptor
  --s->top;
  *e = s->base[s->top];
  --s->size;
}


/*--------------
Access functions
--------------*/


void stack_consult(elt_t *e)
//--------------------------
{
  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e
  *e = s->base[s->top - 1];
}


boolean_t stack_is_empty()
//------------------------
{
  return s->size == 0;
}


boolean_t stack_is_full()
//-----------------------
{
  return s->size == s->capacity;
}


boolean_t stack_is_mem_av()
//-------------------------
{
  return TRUE;
}


/*---------------
Traverse function
---------------*/


void stack_traverse(void fct(buf_t *), buf_t *buf)
//------------------------------------------------
{
  long tmp = s->top;
  
  while (tmp != 0) {
    buf->elt1 = &s->base[--tmp];
    fct(buf);
  }
}
