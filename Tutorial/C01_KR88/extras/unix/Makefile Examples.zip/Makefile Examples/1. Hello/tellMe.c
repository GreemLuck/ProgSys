#include <stdio.h>
void tellMe () {printf("hello\n");}
