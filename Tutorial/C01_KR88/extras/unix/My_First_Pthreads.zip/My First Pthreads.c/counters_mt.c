   /*-----------------------------------------------------------------------------
Short description: My third thread program: ping-pong revisited. 

Description: Similar to version 2, but this time n_t threads are created and
each of it displays its tid. The program illustrates how to:

   - pass to a thread a simple data structure of 4 bytes (size of a 
     void *), e.g. long
     
   - return a simple data structure of 4 bytes to the calling thread
     
   - detect that a pthread has not been created (by creating a big number
     of threads) and how to do the error treatment
     
Usage:    progr_name <n_t> <ms>  (quit by hitting a key)

Examples: prog_name 2     1000
                    2     0
                    100   1000
                    100   0
                    5000  1000
                    5000  0

Author: Beat Hirsbrunner
Version: 1.0, 29 March 2009 / rev. 14 April 09, 3 Dec. 09
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>          // EXIT_SUCCESS
#include <pthread.h>
#include <unistd.h>          // sleep, usleep

#include "silent_getchar.c"  // silent_getchar


/*---------------------------------------------------*/
/*-----   Shared data structure and variables   -----*/
/*---------------------------------------------------*/
int ms;  // passive waiting of ms millisecond before writing a ping or pong

int kb_hit = 0; // continuously read by the pthreads, and written to 1 (true)
                // by the main thread to indicate to all pthreads to terminate


/*-------------------------------*/
/*-----   Thread function   -----*/
/*-------------------------------*/
void *display(void *arg) 
{
   
   int thread_id = (int) (long) arg;  // casting void pointer to long, then to int !!!   
   unsigned long n=0;

   /*-----   main loop   -----*/ 
   while(!kb_hit) { // exit the loop once kb_hit has been set to 1 by the main thread
      ++n;
      printf("%5d", thread_id);
      fflush(stdout);      
      usleep(ms*1000);  // if ms>0, sleep and 'yield' the processor to another thread
      if (ms==0) sched_yield();  // yield the processor to another thread,
                                 // if this has not yet been done by usleep
   }
  
   pthread_exit((void *) n);  // report n to the "parent" thread 
}


/*-----------------------------*/
/*-----   main function   -----*/
/*-----------------------------*/
int main(int argc, char **argv) {
   const int MAX_THREADS = 10000;  // maximal number of threads
   pthread_t threads[MAX_THREADS];
   unsigned long res[MAX_THREADS];
   int t, n_t, rc;

   if (argc != 3) {
	   fprintf(stderr, "-----Usage: %s <n_t> <ms>  (quit by hitting a key)\n", argv[0]);
	   exit(-1);
	}

   printf("quit by hitting a key\n");

   /*-----   Initialization   -----*/
   n_t = atoi(argv[1]);   // number of pthreads
   if (n_t>MAX_THREADS) {
	   fprintf(stderr,"n_t=%d must be smaller or equal %d\n", n_t, MAX_THREADS);
	   exit(-1);
   }   
   ms =  atoi(argv[2]);   // in msec
      
   /*-----   Threads creation   -----*/
   for (t=0; t < n_t; t++) {  // create and run n_t threads
      rc = pthread_create(&threads[t], NULL, display, (void *) (long) t);
      if (rc) {  //----- ERROR TREATMENT
         n_t = t;
         break;
      }
   }

   /*-----   Wait until a key is pressed   -----*/
   silent_getchar();
   // sleep(60);    // instead of silent_getchar()
   // printf("\a"); // alert (bell) character
   kb_hit = 1;

   
   /*-----   Threads join   -----*/
   for (t=0; t < n_t; t++) {  // join all n_t threads
       pthread_join(threads[t], (void *) &res[t]);
   }
   
   /*-----   Termination and possibly warning treatment   -----*/
   printf("\nBye bye from main thread\n"); 
   for (t=0; t < n_t; t++) {  // join all n_t threads
	     printf("%8lu", res[t]);
   }
   printf("\n");

   if (rc) printf("WARNING from main: only %d threads could be created. Return code from pthread_create() is %d\n", n_t, rc);
   return (EXIT_SUCCESS);
}