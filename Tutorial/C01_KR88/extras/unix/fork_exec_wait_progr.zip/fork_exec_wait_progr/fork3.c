/*--------------------------------------------------------------------------------
Title: Process creation (visit 3)
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 06, Dec. 11

DESCRIPTION
Similar to 'fork1.c' program, but with different codes to be executed by the 
parent and child processes, and augmented by passive and active waitings.

USAGE
% fork3

EXERCISE
Explain what happens and verify your answer on machine with the help of a 
performance tool, e.g. top or OSX' Activity Monitor.  
--------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() 
{  
  if (fork() == 0) { // Child process
    printf("> Hello from the child process. Type a character to continue\n");
    getchar();   // passive waiting
    printf("> Hello from the child process just before the infinite loop\n");
    while (1) {} // active waiting
  } 
  else  { // Parent process
    printf("> Hello from the parent process. Type two characters to continue\n");
    getchar(); getchar(); // passive waiting
    printf("> Hello from the parent process just before the infinite loop\n");
    while (1) {}          // active waiting
  }
  return 0;
}