/*----------------------------------------------------------------------------
Automatic Program Testing : a very simple example

Usage: 
   t5_a               //--- Interactive mode
                      //--- Type a character after the display of the prompt '>'
   t5_a > res_ai.txt  //--- Dito

   t5_a < t5.txt                //--- Batch mode
   t5_a < t5.txt  > res_ab.txt  //--- Dito
   
Beat Hirsbrunner, 1 September 2011
----------------------------------------------------------------------------*/
#include <stdio.h>

char f(char c) { return c; }      // a potential existing implementation
char my_f(char c) { return c; }   // a potential new implementation

int main() {
   char c;

   fprintf(stderr,">");   
   while ( (c=getchar()) != EOF ) {  
      //--- automatic checking; only errors are signaled
      if ( my_f(c) != f(c) ) printf("ERROR -- %c, %c, %c\n", c, my_f(c), f(c));  

      while (getchar() != '\n') {} // skip end of line
      fprintf(stderr,">");
   }
   fprintf(stderr,"\n");   
 
   fprintf(stderr,"--- All tests have been performed\n");
   return 0;
}