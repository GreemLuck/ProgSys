/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: UL v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // exit, malloc, free
#include "STACK_SR_Specif.h"


/*--- sketch of the data structure ------------

         /---|*| <---|*| <---|*|
                 pred         |
                             top
---------------------------------------------*/


//--- data type
typedef struct p_node_t {  // node of a 'simple linked' predecessor list
  int e;                   // element to be stored in a node
  struct p_node_t *pred;   // points to the predecessor node
} p_node_t;


//--- shared variable
static p_node_t *top = NULL;


//--- stack subroutines
void stack_put(int e)
{
  p_node_t *tmp = malloc(sizeof *tmp);           // memory allocation: next node
                                                      // (is deallocated by get)
  tmp->e = e;       // copy e
  tmp->pred = top;  // connect 'tmp' node to the stack  
  top = tmp;        // update shared 'top'
}

int stack_get()
{
  if (top == NULL) exit(EXIT_FAILURE); // stack is empty

  p_node_t *tmp = top;  // local variable 'tmp' points to top node
  int e = tmp->e;       // top element to be returned
  
  top = tmp->pred;  // update shared 'top'
  free(tmp);        // free the space of the old top node

  return e; // return top-pre element
}