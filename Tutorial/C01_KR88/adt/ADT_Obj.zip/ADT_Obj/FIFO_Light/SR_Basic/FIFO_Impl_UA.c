/*--------------------------------------------------------------------------------
FIFO subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: UA v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // exit, malloc, realloc
#include "FIFO_SR_Specif.h"


/*--- sketch of the data structure ---------
           -----------------------------
           |   |   | * | * | * |   |   | 
           ----------------------------- 
             |       h           t
            base
------------------------------------------*/


//--- shared variables
#define INIT_CAP 2  // initial capacity of the fifo, > 0

static int *base;     // points to the base elt of the fifo array
static int head = 0;  // pseudo pointer refering to the head
static int tail = 0;  // pseudo pointer refering to the next free entry
static int size = 0;  // 'head' equal 'tail' means that the fifo is empty or full;
                      // to differentiate both cases, 'size' is used
static int capacity = INIT_CAP;  // current fifo capacity, >= INIT_CAP

#include "fifo_new_capacity.c"                                          //---YYY


//--- fifo subroutines
void fifo_put(int e)
{
  static int i = 0;     //--- tricky, used to create a first fifo array storage
  
  if (i++ == 0) {         //--- memory allocation the first time 'put' is called
    base = malloc(capacity * sizeof(int));
  }
  else if (size == capacity) {                  //--- possibly find a free place
    fifo_new_capacity(2*capacity);                     //--- memory reallocation
  }
    
  base[tail] = e;
  tail = (tail + 1) % capacity;
  ++size;
}

int fifo_get()
{
  if (size == 0) exit(EXIT_FAILURE); // fifo is empty
   
  if (capacity/2 > size && capacity > INIT_CAP) //--- possibly decrease fifo's cap
  {
    fifo_new_capacity(capacity/2);
  }
    
  int tmp = base[head];
  head = (head + 1) % capacity;
  --size;
  return tmp;
}