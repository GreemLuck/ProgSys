/*--------------------------------------------------------------------------------
Title: Program overlay - a variant
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 2006

DESCRIPTION
A recursive variant of the 'exec1.c' program !

USAGE
% exec2rec // ATTENTION: recursive call!!!! 
           // To be observed with a performance tool, i.e. top or OSX' Activity
           // Monitor.

EXERCISE
What happens? Verify on machine and explain your observation. If necessary draw 
the 'Process Model Diagram' and pay a particular attention to the arguments passed 
to the program.
--------------------------------------------------------------------------------*/

#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) 
{
  printf("> Before the call of the program '%s' with 'execlp'\n", argv[0]);
  
  execlp(argv[0],argv[0],NULL);
  
  printf("> Couldn't execute '%s'\n", argv[0]);
  return 0;
}
