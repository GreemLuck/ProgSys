/*-------------------------------------------------------------------------------
ADT object subroutines specification (for object = STACK and FIFO)
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: Basic v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

typedef enum obj_t {STACK, FIFO} obj_t;

void put(obj_t obj, int e);
int get(obj_t obj);
