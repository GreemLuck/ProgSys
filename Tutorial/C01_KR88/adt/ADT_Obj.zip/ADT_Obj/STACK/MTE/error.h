/*--------------------------------------------------------------------------------
The "error.h" header file defines the various errors that can occur during 
program execution in the Mini Test Environment (MTE). They are visible to user 
programs.

Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: 1.0, 31 May 2005; rev. 31 May 07, 20 Nov. 11, 15 Nov. 12, 10 March 13
--------------------------------------------------------------------------------*/

char* MTE_error;  // place where the errors go

// possible string values of MTE_error 
// (the default value is an empty string, and indicates no error)

#define MTE_ERROR_not_yet_implemented  "not yet implemented"
#define MTE_ERROR_out_of_memory        "out of memory"

#define MTE_ERROR_data_string_length_is_too_long  "data string length is too long"

#define MTE_ERROR__object_is_empty         "object is empty"
#define MTE_ERROR__object_is_full          "object is full"
#define MTE_ERROR__object_is_not_existing  "object is not existing"

#define MTE_ERROR__negative_capacity_is_not_allowed  "negative capacity is not allowed"
#define MTE_ERROR__new_capacity_is_too_small         "new capacity is too small"

#define MTE_ERROR__node_has_no_predecessor  "node has no predecessor"
#define MTE_ERROR__node_has_no_successor    "node has no successor"

#define MTE_ERROR__no_node_is_behind_the_token  "no node is behind the token"
#define MTE_ERROR__no_node_is_ahead_the_token   "no node is ahead the token"
#define MTE_ERROR__no_arc_is_behind_the_token   "no arc is behind the token"
#define MTE_ERROR__no_arc_is_ahead_the_token    "no arc is ahead the token"

#define MTE_ERROR__node_has_no_parent       "node has no parent"
#define MTE_ERROR__node_has_no_left_child   "node has no left child"
#define MTE_ERROR__node_has_no_right_child  "node has no right child"
