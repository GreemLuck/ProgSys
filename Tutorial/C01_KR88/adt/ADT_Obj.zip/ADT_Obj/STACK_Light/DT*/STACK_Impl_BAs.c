/*--------------------------------------------------------------------------------
STACK subroutines implementation
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: BAs v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdlib.h>  // exit, malloc, realloc, free
#include "../MTE/type_f.h"
#include "../DT*/STACK_DT_Specif_BAs.h"                                 //---YYY
#include "../ADT/STACK_SR_Specif.h"


/*------------------
Private declarations
------------------*/

/*----------------------------------------------                        //---YYY
typedef struct stack_descr_t {
  elt_t *base;    // points to the base elt of the STACK array instance
  long top;       // pseudo pointer referring to the next free entry
  long size;      // 0 <= size <= capacity
  long capacity;  // capacity of the STACK instance, >= 0
} stack_descr_t;
----------------------------------------------*/                        //---YYY

/*--- sketch of the data structure ---------
           -----------------------------
           | * | * | * | * |   |   |   | 
           ----------------------------- 
             |              top
            base
------------------------------------------*/


/*----------
Constructors
----------*/


void stack_create(stackt *_s, long capacity)
//------------------------------------------
{
  stack_descr_t *s;
  
  //--- verify precondition
  if (capacity < 0) exit(EXIT_FAILURE); // negative capacity is not allowed

  //--- possibly find a free place and update descriptor
  s = malloc(sizeof *s);                  // memory allocation: STACK descriptor
                                            // (is deallocated by stack_destroy)
  
  s->base = malloc(capacity * sizeof(elt_t)); // memory allocation: STACK instance
                                              // (is deallocated by stack_destroy)

  s->top = 0;
  s->size = 0;
  s->capacity = capacity;
  *_s = s;
}


void stack_destroy(stackt *_s)
//----------------------------
{
  stack_descr_t *s = *_s;
  
  free(s->base);                                          // free STACK instance
  free(s);                                              // free STACK descriptor
  *_s = NULL;                                          // STACK no longer exists
}


/*----------
Manipulators
----------*/


void stack_put(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == s->capacity) exit(EXIT_FAILURE); // stack is full
  
  //--- copy *e and update descriptor
  s->base[s->top] = *e;
  ++s->top;
  ++s->size;
}


void stack_get(stackt _s, elt_t *e)
//---------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e and descriptor
  --s->top;
  *e = s->base[s->top];
  --s->size;
}


/*--------------
Access functions
--------------*/


void stack_consult(stackt _s, elt_t *e)
//-------------------------------------
{
  stack_descr_t *s = _s;

  //--- verify precondition
  if (s->size == 0) exit(EXIT_FAILURE); // stack is empty

  //--- update *e
  *e = s->base[s->top - 1];
}


boolean_t stack_is_empty(stackt _s)
//---------------------------------
{
  stack_descr_t *s = _s;
  return s->size == 0;
}


boolean_t stack_is_full(stackt _s)
//--------------------------------
{
  stack_descr_t *s = _s;
  return s->size == s->capacity;
}


boolean_t stack_is_mem_av(stackt _s)
//----------------------------------
{
  return TRUE;
}


/*---------------
Traverse function
---------------*/


void stack_traverse(stackt _s, void fct(buf_t *), buf_t *buf)
//-----------------------------------------------------------
{
  stack_descr_t *s = _s;
  long tmp = s->top;
  
  while (tmp != 0) {
    buf->elt1 = &s->base[--tmp];
    fct(buf);
  }
}
