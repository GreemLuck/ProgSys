/*--------------------------------------------------------------------------------
Title: Process creation
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 06, May 07, 
Nov. 10, Dec. 11
Reference: Brian W. Kernighan, Rob Pike: "The Unix Programming Environment",
           Prentice-Hall, 1984, chap. 7.4 Processes (pp. 220-225). 
           See also the Unix man page 'fork'.

DESCRIPTION
fork() causes creation of a new process.  The new process (child process) is an 
exact copy of the calling process (parent process) except for the following:

  o  The child process has a unique process ID.

  o  The child processes resource utilizations are set to 0.

Upon successful completion, fork() returns a value of 0 to the child process and 
returns the process ID of the child process to the parent process.  Otherwise, a 
value of -1 is returned to the parent process, no child process is created, and 
the global variable errno is set to indicate the error.

USAGE
% fork1

EXERCISE
1. Explain what happens and verify your answer on machine.
   
2. Explain what happens if the following statements are added just before the end 
   of the program:
   
      printf("> Before 2\n");
      fork();
      printf("> After  2\n");
	  
   Draw the 'parent-child' processes hierarchy and verify your answer on machine.
--------------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() 
{
  printf("> Before\n");
  fork();
  printf("> After\n");
  return 0;
}
