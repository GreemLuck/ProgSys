#include <stdio.h>
main () {printf("hello\n");}
