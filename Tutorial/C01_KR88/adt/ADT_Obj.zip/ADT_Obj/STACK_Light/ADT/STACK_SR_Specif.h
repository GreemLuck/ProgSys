/*-------------------------------------------------------------------------------
STACK subroutines specification
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: ADT v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

/*----------
Constructors
----------*/
void stack_create (stackt *s, long cap); // 'cap' is not used for UL implementations
void stack_destroy(stackt *s);

/*----------
Manipulators
----------*/
void stack_put(stackt s, elt_t *e);
void stack_get(stackt s, elt_t *e);

/*--------------
Access functions
--------------*/
void       stack_consult    (stackt s, elt_t *e);
boolean_t  stack_is_empty   (stackt s);
boolean_t  stack_is_full    (stackt s);
boolean_t  stack_is_mem_av  (stackt s);

/*---------------
Traverse function
---------------*/
void stack_traverse(stackt s, void fct(buf_t *), buf_t *buf);