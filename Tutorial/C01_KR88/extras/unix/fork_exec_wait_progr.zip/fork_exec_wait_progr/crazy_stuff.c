/*--------------------------------------------------------------------------------
Title: What happens ?
Author: B. Hirsbrunner, University of Fribourg, June 2006, rev. June 2007

DESCRITPTION
This program is really crazy: fork and exec appearing as printf's argument!!!

USAGE
% crazy_stuff [-oteE]

REMARK
Beware, a complete comprehension of the behavior of this program is really hard
and requires a deep knowledge of: (1) function calls and how the arguments of a 
function are handeld, (2) fork, and (3) exec. 

    ONLY FOR STUDENTS LOVING THIS KIND OF STUFF (e.g. Linux hackers)

QUESTIONS
Q1. Explain the number of created processes.

Q2. Explain the pid values printed by printf. Hint: remember the execution stack 
in every programs!

Q3. Why is a single character enough to finish all programs? Hint: fork() creates
a clone with shared system variables! 

But why is this not so if the parent process is retarded by some code?

Q4. Invent your own crazy call!

HINTS 
H1. Draw the 'Execution stack diagram' for the printf() call.

Remember that in C, the arguments of a function are pushed on the execution stack 
from right to left, but the evaluation can be done in any order; under 'PowerPC_
OSX 10.4' gcc evaluates the arguments from left to right, and under 'Intel_
OSX 10.4' and also 'Intel_Ubuntu' from right to left!

H2. Draw also the 'Process model diagram' for the system calls fork() and exec(). 

H3. Finally, verify your answer on machine with the help of a performance tool,
e.g. top or OSX' Activity Monitor.
--------------------------------------------------------------------------------*/
#include <stdio.h>
#include <unistd.h>

void print_usage() {
  printf("usage: crazy_stuff -[oteE]  // -o)ne fork, -t)wo forks, -e)xec+fork");
  printf(", -E)fork+exec\n");
}

int main(int argc, char *argv[]) 
{ 
  if (argc==1 || (argc ==2 && argv[1][0]!='-')) {print_usage(); return -1;}
  
  printf("'during' the printf call ");
  switch (argv[1][1]) {
    case 'o': printf("%d\n",       fork()); break; 
    case 't': printf("%d %d\n",    fork(), fork()); break;
    case 'e': printf("%d %d\n", fork(), execlp("date","date",NULL)); break;
    case 'E': printf("%d %d\n", execlp("date","date",NULL), fork()); break;
    default:  print_usage(); return -1; break;
  }
    
  printf("my_pid=%i\n", getpid());
  printf("Type a character and return to finish the program: \n");
  getchar();
  return 0;
}
