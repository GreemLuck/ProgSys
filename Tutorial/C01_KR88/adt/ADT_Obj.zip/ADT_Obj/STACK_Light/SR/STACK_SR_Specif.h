/*-------------------------------------------------------------------------------
STACK subroutines specification
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: SR v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#define STACK_SR_SPECIF_VERSION "STACK SR specification version : SR v4.1, 10 March 2013"

/*----------
Constructors
----------*/
void stack_create (long capacity); // 'capacity' is not used for UL implementations
void stack_destroy();

/*----------
Manipulators
----------*/
void stack_put(elt_t *e);
void stack_get(elt_t *e);

/*--------------
Access functions
--------------*/
void       stack_consult    (elt_t *e);
boolean_t  stack_is_empty   ();
boolean_t  stack_is_full    ();
boolean_t  stack_is_mem_av  ();

/*---------------
Traverse function
---------------*/
void stack_traverse(void fct(buf_t *), buf_t *buf);