void swap(int *px, int *py)  /* interchange *px and *py  ---  kr96 */
{
  int temp;
	
  temp = *px;
  *px = *py;
  *py = temp;
}
