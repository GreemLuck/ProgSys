/*--------------------------------------------------------------------------------
Title: System call wait in combination with fork and exec
Author: B. Hirsbrunner, University of Fribourg, June 2005, rev. June 07, Dec. 11
Reference: Brian W. Kernighan, Rob Pike: "The Unix Programming Environment",
           Prentice-Hall, 1984, chap. 7.4 Processes (pp. 220-225)

DESCRITION
Very often the parent process waits for the child to terminate before continuing
itself. This is done with the system call wait.

The status returned by wait encodes in its lower bits the system's idea of the
child's exit status; it is zero for normal termination and non-zero to indicate
various kinds of problems. The next higher bits are taken from the argument of the
call to exit or return from main that caused termination of the child process.

This program combines the three system calls 'fork', 'execvp' and 'wait' in a 
natural way.

USAGE
% few1 prog_name
   (where 'prog_name' is the name of a program in the search path $PATH or 
   'prog_name' contains the full pathname)
   
EXERCISES
Explain and verify on machine the behavior of:
1. % few1 date
2. % few1 pwd
4. % few1 exec1
--------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) 
{
  int pid, status;
  
  if (argc < 2) {
    printf("usage: few1 prog_name\n");
	return -1;
  }
   
  pid = fork();
  if (pid==-1) { // Error, the fork call didn't worked
    printf("> Error: the fork call didn't worked\n");
    return -1;
  } 
  else if (pid==0) { // Child process
    printf("\n> Hello, I'm the child process\n");
    printf("> My pid is %i and my parent pid is %i\n", getpid(), getppid());
    printf("> and I will launch the '%s' command\n", argv[1]);
    execlp(argv[1],argv[1],NULL);
  } 
  else { // Parent process
    printf("\n> Hello, I'm the parent process. The pid of my child is: %i\n", pid);
    printf("> My pid is %i and my parent pid is %i\n", getpid(), getppid());
    wait(&status); 
    printf("\n> My child %i terminated with status = %i\n", pid, status);
  }
  return 0;
}
