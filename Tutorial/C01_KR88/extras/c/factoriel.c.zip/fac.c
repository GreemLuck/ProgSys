/*----- 
Author: Beat Hirsbrunner, University of Fribourg, Switzerland, March 2004; rev. March 2008

Original code, see lecture notes, chap. 4.10

    int fac(int n) {if (n>1) return n*fac(n-1); else return 1;}
    main () {printf("%d\n", fac(getchar()-'0')); return 0;}

-----*/


/*------------------------------------------------------  
Similar code, but with 
  - standard pagination
  - standard input/output
  - and allowing fac's argument to be bigger than 9 !
------------------------------------------------------*/  

#include <stdio.h>

int fac(int n) 
{
   if (n>1) 
      return n*fac(n-1); 
   else 
      return 1;
}

main () 
{
   int n;
   
   scanf("%i", &n);
   printf("%d\n", fac(n));
   return 0;
}