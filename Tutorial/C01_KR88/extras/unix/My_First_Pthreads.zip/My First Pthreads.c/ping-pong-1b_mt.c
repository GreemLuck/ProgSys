/*-----------------------------------------------------------------------------
 
Description: One thread displays ping and the other PONG. The program 
illustrates how to:

   - pass a data structure to a thread
   - return a data structure to the calling thread
   
Usage:   progr_name

Author: Beat Hirsbrunner
Version 1.0: 10 Deccember 2011
-----------------------------------------------------------------------------*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>   // malloc, free
#include <unistd.h>   // sleep, usleep

/*-----   Shared data structures   -----*/
struct pthread_data_t   {int tid; char *mssg; int buf;};
struct pthread_result_t {int key; char *mssg;};

/*-----   Thread function   -----*/
void *display(void *arg) 
{
   struct pthread_data_t *data  = arg;                  // implicit casting
   struct pthread_result_t *res = malloc(sizeof *res);  // dynamic memory allocation

   printf("thread %d: %s \n", data->tid, data->mssg);
   
   //---   transmit infos to the calling thread via the calling parameter 'arg'
   data->buf = data->tid; 

   //---   another way to transmit infos to the calling thread via pthread_exit()
   res->key = data->tid;  
   if (data->tid % 2) res->mssg = "BLONG"; else res->mssg = "bling";
   
   //---   report 'res' to the calling thread 
   pthread_exit(res); // implicit casting of res to void *
}

/*-----   main function   -----*/
int main() 
{
   pthread_t                thread[2];
   struct pthread_data_t    data[2] = { {0,"ping",0}, {1,"PONG",0} };    
   struct pthread_result_t  *res[2] = {NULL, NULL};

   /*-----   Create two threads   -----*/
   pthread_create(&thread[0], NULL, display, &data[0]);
   pthread_create(&thread[1], NULL, display, &data[1]);
   
   sleep(2);
   /*-----   Wait the exit of the two created threads   -----*/
   pthread_join(thread[0], (void **) &res[0]);
   pthread_join(thread[1], (void **) &res[1]); 
   
   /*-----   Termination   -----*/   
   printf("thread main: %i %i %s, %i %i %s \n", 
          data[0].buf, res[0]->key, res[0]->mssg,
          data[1].buf, res[1]->key, res[1]->mssg); 
   
   free(res[0]);  // deallocate memory allocated by the two child threads !
   free(res[1]);
   
   return 0;
}