/*--------------------------------------------------------------------------------
Title: Simple test program with error treatment
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland
Version: version 1, 9 September 2007

Description: Read from the standard input a key (integer) and a word (C string), 
and print them.

Usage: prog_name  

Comment: The input may contain misformatted data; in this case the rest of the 
line is skipped.
--------------------------------------------------------------------------------*/

#include <stdio.h>

int main() {
  int key;
  char word[20];
  char c;  //--- for error treatment
    
  printf("> enter an integer followed by a string\n");

  // Read the data (with error treatment) ----------------------------
  while (scanf("%d %s", &key, word) < 2) {
    
	//--- error treatment
	while ((c=getchar()) != '\n') 
		; // skip the rest of the input line
    printf("Input format error. Try again.\n");
  }
  // -----------------------------------------------------------------
  
  // Do some action (here nothing is done)
	
  printf("%d %s\n", key, word);  // Print the result
}