void swap(int x, int y)  /* WRONG --- kr95 */
{
  int temp;

  temp = x;
  x = y;
  y = temp;
}
