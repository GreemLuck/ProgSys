/*-----------------------------------------------------------------------------
This function is intended to be included in FIFO's UA implementations

As the code is rather tricky, it has been put in a separate file: this will 
simplify its future refactoring, as it exists only in one place and is not hidden
in possibly multiple files !

Assumptions: 
1) realloc is successfull, i.e. no error checking is performed.
2) 'base', 'head', 'tail', 'size', 'capacity' are shared global FIFO implementation
   variables

© Béat Hirsbrunner, version 1, 20 October 2012, rev. 10 March 2013
-----------------------------------------------------------------------------*/

void fifo_new_capacity(int nc)
//----------------------------
{  
  long i;
  long shift; // number of elements to be freed
  long max;   // number of elements to be shiftet;

  //---------------------------   Easy cases   --------------------------------
  if (nc < 0 || nc < size) exit(-1);

  if (nc == capacity) return;  // do nothing  

  if (size == 0)     //--- reallocate the new region and update shared variables
  {
    base = realloc(base, nc*sizeof(int)); 
    
    head = 0;
    tail = 0;
    capacity = nc;
    return;    
  }
  
  //----------------------------   Tricky cases   ------------------------------
  //--- At this point we have: 
  //---   nc >= size, i.e. there is enough place to store all elts in the new array
  //---   nc != capacity
  //---   0 < size <= capacity, i.e. if tail == head then FIFO is full !
  //---
  //--- Tricky: the elements present in the FIFO have possibly to be shiftet,
  //---         and at least one is present!
      
  if (nc > capacity) // reallocate a bigger region
  //----------------------------------------------
  {
    //--- create the greater region
    base = realloc(base, nc*sizeof(int));              //--- memory reallocation               
    
    //--- possibly shift elements          
    if (tail <= head)
    {
      //------------------------------------------------------------------------
      // Shift forward the elts '0..tail-1' of 'capacity modulo nc' slots:
      //
      //  ---------------------         -------------------------------------
      //  | B | C |   |   | A |   --->  |   |   |   |   | A | B | C |   |   |
      //  ---------------------         -------------------------------------
      //            t       h                             h           t  nc-1
      //------------------------------------------------------------------------
      max = tail;
      shift = capacity;
      for (i=0; i<max; ++i) {
        base[(i+shift) % nc] = base[i]; 
      }
      tail = (tail + shift) % nc;
      // note: head is untouched !   
    }
    
    capacity = nc; // new capacity
    return;
  } 

  if (nc < capacity) // reallocate a smaller region
  //-----------------------------------------------
  //--- remember: 0 < size <= nc < capacity
  { 
    //--------------------------------------------------------------------------
    // idea: free all 'capacity - nc' slots at the end of the array 
    // by shifting back the elements by starting by the head 
    //
    //  -----------------------------         -----------------------------
    //  | C |   |   |   |   | A | B |   --->  | C |   |   | A | B | - | - |
    //  -----------------------------         -----------------------------
    //        t               h                     t       h  nc-1
    //--------------------------------------------------------------------------

    //--- calculate shift and max
    if (tail < head)     
    {                         // the end of the array is full
      shift = capacity - nc;  // number of elements to be freed
      max = capacity - head;  // number of elements to be shifted
    } 
    else                             
    {                     // the end of the array is not full, tail > head
      shift = tail - nc;  // number of elements to be freed
      max = tail - head;  // number of elements to be shifted
    }
    
    //--- possibly shift elements
    if (shift>0)  // if shift is zero or negative, no shift is necessary
    {  
      for (i=0; i<max ; ++i)  // shift the elements to the left of 'shift' slots
      {
        base[head + i - shift] = base[head + i];
      }
      head = head - shift;  // new head
    }
    // the needed slots at the end of the array are now 'freed'
    
    base = realloc(base, nc*sizeof(int));              //--- memory reallocation   

    tail = (head + size) % nc; // new tail
    capacity = nc;             // new capacity
    return;
  } 
}