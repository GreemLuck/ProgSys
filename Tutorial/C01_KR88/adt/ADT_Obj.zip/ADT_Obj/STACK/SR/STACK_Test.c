/*--------------------------------------------------------------------------------
STACK test program
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: SR v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdio.h>     // printf, scanf
#include <stdlib.h>    // srand, rand, malloc, free
#include <string.h>    // strcpy, strlen
#include <sys/time.h>  // struct timeval, gettimeofday
#include <time.h>      // clock, CLOCKS_PER_SEC
#include <unistd.h>    // isatty 

#include "../MTE/error.h"
#include "../MTE/type_f.h"                                              //---YYY
#include "../SR/STACK_SR_Specif.h"                                      //---YYY

#define STACK_TEST_VERSION "STACK test program version: SR v4.1, 10 March 2013"

typedef struct res_size_t // used by size()
{
  long nb_elt;    // number of elements 'elt' stored in the STACK
  long size_elt;  // size in bytes of all elt
  long size_key;  // size in bytes of all elt->key
  long size_data; // size in bytes of all elt->data
  long size_str;  // size in bytes of the strings stored by all elt->data
} res_size_t;

long my_utime()  // Local Time (LT) in usec
//-----------------------------------------
//Returns the current time, as seconds and microseconds since the Epoch, with the
//best resolution the hardware can offer. On most platforms the resolution is one
//microsecond or better, although some platforms offer only jiffies resolution.
{
  //  struct timeval {
  //    time_t       tv_sec;   // seconds since Jan. 1, 1970
  //    suseconds_t  tv_usec;  // and microseconds
  //  } tp;
  
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return (long)(tv.tv_sec)*1000L*1000L + (long)tv.tv_usec;
}

void display(buf_t *buf)  // user supplied function for traverse
//--------------------------------------------------------------
{
  //--- prints all elements of the STACK
  printf("%li %s\n", buf->elt1->key, buf->elt1->data);
} 

void occurrence(buf_t *buf)  // user supplied function for traverse
//-----------------------------------------------------------------
{ 
  //--- counts the occurences of user supplied 'buf->elt2->key'
  if (buf->elt1->key == buf->elt2->key) ++*(long *)buf->res; 
} 

void size(buf_t *buf)  // user supplied function for traverse
//-----------------------------------------------------------
{ 
  //--- counts miscellaneous sizes of the STACK 
  res_size_t *tmp = buf->res; //local variable tmp just to avoid annoying castings
  ++tmp->nb_elt;
  tmp->size_elt  += sizeof(*buf->elt1);
  tmp->size_key  += sizeof(buf->elt1->key);
  tmp->size_data += sizeof(buf->elt1->data);
  tmp->size_str  += strlen(buf->elt1->data);
} 

void do_nothing(buf_t *buf)  // user supplied function for traverse
//-----------------------------------------------------------------
{
  //--- if the STACK contains more items than the main memory can handle
  //--- then, depending on the implementation of the STACK, traverse possibly
  //--- generates 'page ins', but no 'page outs'
} 

void read_only(buf_t *buf)  // user supplied function for traverse
//----------------------------------------------------------------
{
  //--- if the STACK contains more items than the main memory can handle
  //--- then this code generates 'page ins', but no 'page outs'
  int i; i = buf->elt1->key; 
} 

void read_write(buf_t *buf)  // user supplied function for traverse
//-----------------------------------------------------------------
{
  //--- if the STACK contains more items than the main memory can handle
  //--- then this code generates 'page ins' and 'page outs'
  ++buf->elt1->key;
} 

void foo(long i)  // used by command 'Z'
//--------------------------------------
{  
//  long grain = 1000L*1000L;
//  if ( !(i % grain) ) printf("recursive foo: %i\n", i/grain);
//  foo(++i);  // recursive call: will produce a stack segment overflow

//  void *p = malloc(sizeof *p);  // memory allocation (heap segment)
//  free(p);                      // memory deallocation
}

void print_usage()
//----------------
{
  printf("Stack object usage\n");
  printf("------------------\n");
  printf("Constructors :  c)create(i)     d)destroy\n");
  printf("Manipulators :  p)put(i,s)      g)get             n)new_capacity(i)\n");
  printf("Access fcts  :  o)consult\n");
  printf("                e)is_empty      f)is_full         m)is_mem_av\n");
  printf("                E)exists        s)size            C)capacity\n");
  printf("\n");
  printf("                                      V)SR_specif_version\n");
  printf("                i)SR_impl_version     I)SR_impl_type\n");
  printf("\n");
  printf("Traverse fcts:  td)display      to)occurrence(i)  ts)size\n");
  printf("                tn)do_nothing   tr)read_only      tw)read_write\n");
  printf("\n");
  printf("Test program usage\n");
  printf("------------------\n");
  printf("Misc         :  T)Test_version   P)Progr_name\n");
  printf("                H)Help           Q)Quit\n");
  printf("\n");
  printf("Memory usage ([c|t],i): i in ticks [c] or LT usec [t])\n");
  printf("------------------------------------------------------\n");
  printf("Alloc/Dealloc:  X)put/get(*,i)   Y)create/destroy(*,i)  Z)procCall(i)\n");
  printf("Virtual Mem. :  O)Fill_Obj(*,i)  M)Fill_Mem(*,i)\n");  
}

int main(int argc, char *argv[]) 
//------------------------------
{
  // STACK variables
  //----------------
  long capacity = 2;  // default STACK 'capacity'
  stack_create(capacity);  // default stack

  #if __fixed_data_length__  //--- defined in "../MTE/type_f.h" and "../MTE/type_m.h"
    elt_t elt = {1, "Hello"};
  #elif __mutable_data_length__
    elt_t elt = {1, malloc(MTE_MAX_STR_LEN + 1)};
    strcpy(elt.data, "Hello");
  #endif

  buf_t buf = {NULL, NULL, NULL};  // buffer used by traverse
  
  // Test program variables
  //-----------------------
  MTE_error = ""; // By default, there is no error.
                  // Global variable declared in the header file 'MTE_error.h'
                  
  char c;  // 'switch(c)' of the main loop
  
  // t, X, Y, Z, O, M commands
  long li;                  // counter
  long grain = 1000L*1000L; // grain to display only every 'grain' occurrences
  
  char t_variant;                   // variant of counting or timing 
  long t;                           // amount of counting or timing
  long    start_utime, stop_utime;  // LT in microseccond
  clock_t start_clock, stop_clock;  // PT in CLOCKS_PER_SEC
                                    // (1/100 or 1/1000000, hardware dependent)
  // display management
  //-------------------  
  const char *prompt = "> ";
  int prompt_count = 1;
  
  if (isatty(0) && isatty(1)) // 'isatty' is read 'is a tty', i.e. a terminal, with
  {                           // 0 for standard input stream, e.g. keyboard
                              // 1 for standard output stream, e.g. display
    print_usage();
    printf("\nBEWARE, use the virtual memory functionalities O and M with great");
    printf(" care as they may severely crash your machine !!!\n\n");
  }                                
  printf("%i%s", prompt_count++, prompt);
  
  
  /*---------------------------
  Main loop of the test program
  ---------------------------*/
  while ( (c = getchar()) != 'Q')
  {
    switch(c)
    {
      /*----------
      Constructors
      ----------*/      
      case 'c':  // create
        if (scanf("%li", &capacity) != 1) goto error_scanf;//--- ERROR TREATMENT
        
        stack_create(capacity);
        
        if (MTE_error[0] != '\0') goto error_obj;          //--- ERROR TREATMENT
        printf("STACK has been created\n");
        break;
        
      case 'd':  // destroy
        stack_destroy();
        printf("STACK has been destroyed\n");
        break;
        
      /*----------
      Manipulators
      ----------*/
      case 'p':  // put
        if (scanf("%li%s", &elt.key, elt.data) != 2) goto error_scanf;
                                                           //--- ERROR TREATMENT        
        stack_put(&elt);

        if (MTE_error[0] != '\0') goto error_obj;          //--- ERROR TREATMENT
        printf("%li %s\n", elt.key, elt.data);
        break;
        
      case 'g':  // get
        stack_get(&elt);
        if (MTE_error[0] != '\0') goto error_obj;          //--- ERROR TREATMENT
        printf("%li %s\n", elt.key, elt.data);
        break;
        
      case 'n':  // new_capacity
        if (scanf("%li", &capacity) != 1) goto error_scanf;//--- ERROR TREATMENT
        
        stack_new_capacity(capacity);
        
        if (MTE_error[0] != '\0') goto error_obj;          //--- ERROR TREATMENT
        printf("%li\n", stack_capacity());
        break;
        
      /*---------
      Access fcts
      ---------*/     
      case 'o':  // consult
        stack_consult(&elt);
        if (MTE_error[0] != '\0') goto error_obj;          //--- ERROR TREATMENT
        printf("%li %s\n", elt.key, elt.data);
        break;
        
      case 'e':  // is_empty
        if (stack_is_empty())
          printf("yes\n");
        else
          printf("no\n");
        break;
        
      case 'f':  // is_full
        if (stack_is_full()) 
          printf("yes\n");
        else
          printf("no\n");
        break;
        
       case 'm':  // is_mem_av
        if (stack_is_mem_av()) 
          printf("yes\n");
        else
          printf("no\n");
        break;
        
      //----- other access functions   -----
      
      case 'E':  // exists
        if (stack_exists())
          printf("yes\n");
        else
          printf("no\n");
        break;
        
      case 's':  // size
        printf("%li\n", stack_size());
        break;
        
      case 'C':  // capacity
        printf("%li\n", stack_capacity());
        break;
        
      case 'V':  // subroutines specification version
        printf("%s\n", STACK_SR_SPECIF_VERSION);
        break;
        
      case 'i':  // subroutines implementation version
        printf("%s\n", stack_impl_version());
        break;
        
      case 'I':  // subroutines implementation type
        printf("%s\n", stack_impl_type());
	       break;
	       
      /*------------
      STACK traverse
      ------------*/
      case 't':
      { 
        start_utime = my_utime();
        start_clock = clock();
        
        switch (getchar())  //--- subcases of traverse 't'
        {
          case 'd':  // traverse with display
            stack_traverse(display, &buf);
            stop_clock = clock();
            stop_utime = my_utime();
            printf("--- /t display\n");
            break;
		          
          case 'o':  // traverse with occurence
          {
            long res = 0;

            buf.elt2 = &elt; // occurence compares buf.elt2->key with buf.elt1->key
            if (scanf("%li", &buf.elt2->key) != 1) 
              goto error_scanf;                            //--- ERROR TREATMENT
            buf.res = &res;  // *buf.res is updated by occurence
            
            stack_traverse(occurrence, &buf);
            
            stop_clock = clock();
            stop_utime = my_utime();
            printf("%li\n", res);
            printf("--- /t occurrence\n");
            break;
          }
		        
          case 's':  // traverse with size
          {
            res_size_t res = {0, 0, 0, 0, 0};
            buf.res = &res;  // *buf.res is updated by size

            stack_traverse(size, &buf);
            
            stop_clock = clock();
            stop_utime = my_utime();
            printf("%li elts, %li B/elt (%li B/elt.key, %li B/elt.data), %li B strings\n", 
                   res.nb_elt, 
                   res.nb_elt ? res.size_elt/res.nb_elt : sizeof(elt), 
                   res.nb_elt ? res.size_key/res.nb_elt : sizeof(elt.key), 
                   res.nb_elt ? res.size_data/res.nb_elt : sizeof(elt.data), 
                   res.size_str);
            printf("--- /t size\n");
            break;
          }

          case 'n':  // traverse with do_nothing
            stack_traverse(do_nothing, &buf);
            stop_clock = clock();
            stop_utime = my_utime();
            printf("--- /t do_nothing\n");
            break; 
            
          case 'r':  // traverse with read-only
            stack_traverse(read_only, &buf);
            stop_clock = clock();
            stop_utime = my_utime();
            printf("--- /t read_only\n");
            break;
            
          case 'w':  // traverse with read-write
            stack_traverse(read_write, &buf);
            stop_clock = clock();
            stop_utime = my_utime();
            printf("--- /t read_write\n");
            break;
            
          default:
            if (isatty(0) && isatty(1)) print_usage(); else printf("---\n");
            break;
        } // end subcases            
        
        if (stack_size() >= grain)
        {
          printf("elapsed clock (PT in sec) = %.6f \n", ((double)(stop_clock - start_clock))/CLOCKS_PER_SEC);
          printf("elapsed utime (LT in sec) = %.6f \n", ((double)(stop_utime - start_utime))/(1000L * 1000L));
        }
        break;
      } //--- end case 't'
        
      /*-------------------------
      Test Program: miscellaneous
      -------------------------*/
      case 'T':  // test program version
        printf("%s\n", STACK_TEST_VERSION);
        break;
        
      case 'P':  // name of the program
        printf("%s\n", argv[0]);
        break;
        
      case 'H':
        if (isatty(0) && isatty(1)) print_usage(); else printf("---\n");
        break;
        
      /*------------------------------------------------------------------                         
      Memory usage: allocate/deallocate memory as long as time is not over
      (with time measured in ticks or LT usec)
      ------------------------------------------------------------------*/                           
      case 'X':  // verify memory deallocation: 'put*/get*' loop
      {
        stack_create(16);
        int r1, r2;
        li = 0;
              
        srand((unsigned int)clock());
        
        scanf("%c", &t_variant);
        if (scanf("%li", &t) != 1) goto error_scanf;       //--- ERROR TREATMENT

        start_utime = my_utime();  // LT in usec       
        while( t_variant != 't' ? t-- > 0 : my_utime() - start_utime < t )
        {
          r1 = r2 = rand() % 16 + 1;
          
          while(r1-- != 0) stack_put(&elt);                   // allocate memory
          while(r2-- != 0) stack_get(&elt);                 // deallocate memory
          
          if ( !(++li % grain) ) printf("%li\n", li/grain);
        }
        MTE_error = "";                               // without error treatment

        stack_destroy();
        printf("%li\n", li);
        printf("--- /X\n");
        break;
      }
      
      case 'Y':  // verify memory deallocation: 'create/put*/destroy' loop
      {
        int r;
        li = 0;
        
        srand((unsigned int)clock());
        
        scanf("%c", &t_variant);
        if (scanf("%li", &t) != 1) goto error_scanf;       //--- ERROR TREATMENT

        start_utime = my_utime();  // LT in usec       
        while( t_variant != 't' ? t-- > 0 : my_utime() - start_utime < t )
        {
          r = rand() % 16;          
          
          stack_create(r);                                    // allocate memory
          while(r-- != 0) stack_put(&elt);                    // allocate memory
          stack_destroy();                                  // deallocate memory
          
          if ( !(++li % grain) ) printf("%li\n", li/grain);
        }
        MTE_error = "";                               // without error treatment
        
        printf("%li\n", li);
        printf("--- /Y\n");
        break;
      }
      
      case 'Z':  // verify memory deallocation: 'function call' loop
        li = 0;
        
        scanf("%c", &t_variant);
        if (scanf("%li", &t) != 1) goto error_scanf;       //--- ERROR TREATMENT

        start_utime = my_utime();  // LT in usec       
        while( t_variant != 't' ? t-- > 0 : my_utime() - start_utime < t )
        {
          foo(li); // allocate/deallocate memory
          if ( !(++li % (grain)) ) printf("%li\n", li/grain);
        }
        
        printf("%li\n", li);
        printf("--- /Z\n");
        break;
        
      /*-------------------------------------------------------------------                         
      Memory usage: Virtual memory observation: allocate memory as long as time 
      is not over (with time measured in ticks or LT usec)
      
      Beware, use this commands with great care as they may severely crash your
      machine (only Fill_Obj for bounded objects is harmless)
      
      Observe VM behaviour with a tool like 'vmstat' or 'Activity Monitor'
      -------------------------------------------------------------------*/                           
      case 'O':  // fill up current stack object: 'put' loop
        li = 0;     
        elt.key = 0;
        strcpy(elt.data,"Fill up the current obj, with strlen(elt.data): 50");
        
        scanf("%c", &t_variant);
        if (scanf("%li", &t) != 1) goto error_scanf;       //--- ERROR TREATMENT

        start_utime = my_utime();  // LT in usec        
        while ( (t_variant != 't' ? t-- > 0 : my_utime() - start_utime < t) &&
                stack_is_mem_av() &&
               !stack_is_full() )
        {
          ++elt.key;
          stack_put(&elt);
          
          if ( !(++li % grain) ) printf("%li\n", li/grain);
        }
        
        if (MTE_error[0] != 0)                           //--- WARNING TREATMENT
        {
          printf("%s: WARNING: last 'put' failed\n", argv[0]);
          MTE_error = "";
        }
        printf("%li\n", li);
        printf("--- /O\n");
        break;
        
      case 'M':  // fill memory with empty STACKs of current capacity: 'create' loop
                 //--- BEAWRE, none of these STACKs wil be destroyed: to deallocate
                 //--- this memory you have to quit this program !
      { 
        li = 0;
        
        scanf("%c", &t_variant);
        if (scanf("%li", &t) != 1) goto error_scanf;       //--- ERROR TREATMENT

        start_utime = my_utime();  // LT in usec       
        while( t_variant != 't' ? t-- > 0 : my_utime() - start_utime < t )
        {
          stack_create(capacity);
          
          if (MTE_error[0] != '\0') goto error_obj;        //--- ERROR TREATMENT
          if ( !(++li % grain) ) printf("%li\n", li/grain);
        }
        printf("%li\n", li);
        printf("--- /M\n");
        break;
      }
        
      default:
        if (isatty(0) && isatty(1)) print_usage(); else printf("---\n");
        break;
    }
    while (getchar() != '\n') {} /* skip end of line */
    printf("%i%s", prompt_count++, prompt);
    continue;  // all is ok, go to the beginning of the main loop
    
/*----- ERROR TREATMENT -----*/ 
error_scanf:
    while (getchar() != '\n') {} /* skip end of line */
    printf("%s: ERROR: wrong scanf argument\n", argv[0]);
    printf("%i%s", prompt_count++, prompt);
    continue;
error_obj:
    while (getchar() != '\n') {} /* skip end of line */
    printf("%s: ERROR: %s\n", argv[0], MTE_error);
    printf("%i%s", prompt_count++, prompt);
    MTE_error = "";
    continue;
/*----- END ERROR TREATMENT -----*/     
  }
  /*--------------------------------------
  End of the main loop of the test program
  --------------------------------------*/
  #if __mutable_data_length__
    free(elt.data);
  #endif
  printf("Quit\n");
  return 0;
}