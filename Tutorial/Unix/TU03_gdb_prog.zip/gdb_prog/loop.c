#include "stdio.h"

void loop1(void) 
{
  int i,j,k;
  for (i=1; i<=3; ++i) {
     j=i; 
     k=3;
     printf("i=%i, j=%i, k=%i\n",i,j,k);
  }
}

void loop2(void) 
{
  int i,j,k;
  for (i=1; i<=3; ++i) {
     j=i; 
     k=3;
  }
}

main()
{
  loop1();
  loop2();
}

/*--------------------------------------------------------------------------------
Simple program to compile resp. with '-g', '-g -O1' and '-g -fast' options and use
with the GNU debugger gdb
Author: B. Hirsbrunner, University of Fribourg, 12 June 2005
--------------------------------------------------------------------------------*/