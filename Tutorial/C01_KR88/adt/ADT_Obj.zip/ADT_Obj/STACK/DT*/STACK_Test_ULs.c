/*--------------------------------------------------------------------------------
STACK test program
Author: Beat Hirsbrunner, DIUF, University of Fribourg, Switzerland, © 2005-2013
Version: ADT v4.1, 10 March 2013
--------------------------------------------------------------------------------*/

#include <stdio.h>     // printf, scanf
#include <stdlib.h>    // srand, rand, malloc, free
#include <string.h>    // strcpy, strlen
#include <sys/time.h>  // struct timeval, gettimeofday
#include <time.h>      // clock, CLOCKS_PER_SEC
#include <unistd.h>    // isatty 

#include "../MTE/error.h"
#include "../MTE/type_f.h"                                              //---YYY
#include "../DT*/STACK_DT_Specif_ULs.h"                                 //---YYY
#include "../ADT/STACK_SR_Specif.h"

#include "../ADT/STACK_Test_Core.c"